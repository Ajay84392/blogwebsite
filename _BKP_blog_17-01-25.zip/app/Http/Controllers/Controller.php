<?php

namespace App\Http\Controllers;

use Auth;

abstract class Controller
{
    public function isLogged()
    {
        if (Auth::check()) {
            return true;
        }

        return false;
    }

    public static function getUserId()
    {
        return Auth::check() ? Auth::user()->id : 0;
    }
}
