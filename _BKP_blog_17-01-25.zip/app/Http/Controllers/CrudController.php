<?php
namespace App\Http\Controllers;
use App\Models\Crud;
// use App\Models\User;
use Illuminate\Http\Request;
class CrudController extends Controller
{
    public function crudIndex(Request $request)
    {
        $data = [];
        $data['title'] = "This is my login Index page";
        $request->session()->flash('primary', 'Employee submitted successfully!');
        if ($request->isMethod("post")) {
            // die("ajay");exit;
            $input = [
                'full_name' => $request->input('f_name'),
                'email' => $request->input('email_id'),
                'dob' => $request->input('date_of_birth'),
                'state' => $request->input('state_crud'),
                'contact' => $request->input('contact_no'),
                'password' => $request->input('password_pass'),
            ];
            // echo '<pre>';
            // print_r($input);
            $dataInput = Crud::insert($input);
            if ($dataInput) {
                $request->session()->flash('flash_notification.primary', '<strong>Thank You!</strong>, Your Registration Form is successfully Submitted.');
                return redirect("pricing");
            } else {
                return redirect("crud");
            }
            echo '<pre>';
            print_r($input);
            exit;
            die('die here');
            exit;
        }
        // print_r($data);exit;
        return view("crud.crud", ['data' => $data]);
    }
    public function crudDetail(Request $request)
    {
        $data = [];
        $data['Cruds'] = Crud::select('id', 'full_name', 'dob', 'state', 'contact', 'email', 'password')->paginate(10);
        return view("crud.crud-Detail", ['data' => $data]);
    }
    public function crudEdit(Request $request)
    {
        $data = [];
        $data['Crud'] = Crud::where(["id" => $request->id])->select('id', 'full_name', 'dob', 'state', 'contact', 'email', 'password')->first();
        if ($request->isMethod('post')) {
            $input = [
                //    die("ajay");exit;
                'full_name' => $request->input('f_name'),
                'email' => $request->input('email_id'),
                'dob' => $request->input('date_of_birth'),
                'state' => $request->input('state_crud'),
                'contact' => $request->input('contact_no'),
                'password' => $request->input('password_pass'),
            ];
            $dataInput = Crud::where(["id" => $request->id])->update($input);
            // print_r ($request->id);exit;
            return redirect('crud/detail');
        }
        return view("crud.crud-edit", ['data' => $data]);
    }
    public function cruddelete(Request $request)
    {
        $data = [];
        $data['Cruds'] = Crud::where(["id" => $request->id])->delete();
        return redirect("crud/detail");
    }
}
