<?php

namespace App\Http\Controllers;

use App\Models\Blog;
use App\Models\User;
use App\Models\Input;
use App\Models\Fblog;
use App\Models\sblog;
use Egulias\EmailValidator\EmailValidator;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Password;
use Laravel\Pail\Contracts\Printer;
use session;
use Hash;
use Auth;
use Illuminate\Support\Facades\Storage;

class HomeController extends Controller
{
    public function bloglearn()
    {
        $data = [];
        $data['code1'] = Blog::where(['status' => 'active'])->select('image', 'title', 'description', 'id')->get();
        return view("blog.blog-learn", ['data' => $data]);
    }
    public function index()
    {
        $data = [];
        $data['page'] = Blog::where(['status' => 'active', 'type' => 'page'])->select('image', 'title', 'description')->first();
        $data['page1'] = Blog::where(['status' => 'active', 'type' => 'page1'])->select('image', 'title', 'description')->first();
        $data['page2'] = Blog::where(['status' => 'active', 'type' => 'page2'])->select('image', 'title', 'description')->first();
        $data['page3'] = Blog::where(['status' => 'active', 'type' => 'page3'])->select('image', 'title', 'description')->first();
        $data['page4'] = Blog::where(['status' => 'active', 'type' => 'page4'])->select('image', 'title', 'description')->first();
        return view("index", ['data' => $data]);
    }
    public function sblogedit(Request $request, $id)
    {
        $sblog = sblog::findOrFail($id);
        if ($request->isMethod('post')) {
            $input = $request->except(["_token"]);
            if ($request->hasFile('image')) {
                $image = $request->file('image');
                $imageName = date('d') . time() . '.' . $image->getClientOriginalExtension();
                $image->move(public_path('upload/blog'), $imageName);

                $input['image'] = $imageName;
            }
            sblog::where(["id" => $id])->update($input);
            return redirect()->route('sblog-voucher');
        }
        return view('blog.sblog-edit', compact('sblog'));
    }
    public function sblogaddvoucher(Request $request)
    {
        if ($request->isMethod('post')) {
            $data = $request->except('_token');

            if ($request->hasFile('image')) {
                $image = $request->file('image');
                $imageName = time() . '.' . $image->getClientOriginalExtension();
                $image->move(public_path('upload/blog'), $imageName);
                $data['image'] = $imageName;
            }
            sblog::insert($data);
            return redirect()->route('sblog-voucher');
        }
        return view('blog.sblog-addvoucher');
    }
    public function sblogdelete($id)
    {
        $sblog = sblog::findOrFail($id);
        $sblog->delete();
        return redirect()->route('sblog-voucher');
    }
    public function blogvoucher(Request $request)
    {
        $sblogs = sblog::all();
        return view("blog.sblog-voucher", ['sblogs' => $sblogs]);
    }
    public function blogreservation(Request $request)
    {
        if ($request->isMethod("post")) {
            $validatedData = $request->validate([
                'title' => 'required|string|max:255',
                'description' => 'required|string',
                'image' => 'nullable|mimes:png,jpg,jpeg,webp',
                'status' => 'required|in:Active,Inactive',
            ]);
            $data = $request->only(['list', 'description', 'status']);
            if ($request->hasFile('image')) {
                try {
                    $image = $request->file('image');
                    $imageName = time() . '.' . $image->getClientOriginalExtension();
                    $image->move(public_path('public/upload/blog'), $imageName);
                    $data['image'] = 'public/upload/blog' . $imageName;
                } catch (\Exception $e) {
                    return back()->withErrors(['image' => 'Image upload failed: ' . $e->getMessage()]);
                }
            } else {
                $data['image'] = null;
            }
            Blog::create($data);

            return redirect()->route('blog-reservation')->with('success', 'Blog added successfully!');
        }
        $blogs = Blog::all();
        return view("blog.blog-reservation", ['blogs' => $blogs]);
    }
    public function bloglist(Request $request)
    {
        $data = [];
        $data['code2'] = Blog::where(['status' => 'active'])->select('image', 'title', 'description', 'id')->paginate(10);
        $blogs = Blog::where(['type' => 'viewlist'])->orderBy('id', 'DESC')->get();
        return view("blog.blog-list", ['blogs' => $blogs, 'data' => $data]);
    }
    public function blogview(Request $request)
    {
        $data = [];
        $data['code2'] = Blog::where(['status' => 'active'])->select('image', 'title', 'description', 'id')->paginate(10);
        // die ('die here'); exit;
        $blogs = Blog::where(['type' => 'viewblog'])->orderBy('id', 'DESC')->paginate(10);
        return view("blog.blog-list", ['blogs' => $blogs, 'data' => $data]);
    }
    public function blogAdd(Request $request)
    {
        if ($request->isMethod('post')) {
            $data = $request->except('_token', 'redirect_to');
            $type = $request->input('type');
            // echo '<pre>';
            // print_r($type);exit;
            if ($request->hasFile('image')) {
                $image = $request->file('image');
                $imageName = time() . '.' . $image->getClientOriginalExtension();
                $image->move(public_path('upload/blog'), $imageName);
                $data['image'] = $imageName;
            }
            Blog::create($data);
            $redirectTo = $request->input('redirect_to');
            if($type === "viewlist"){
                return redirect()->route("blog-list");

            }else{
                return redirect()->route("blog-view");
            }
            // if ($redirectTo === 'viewblog') {
            //     return redirect()->route('blog-view');
            // } elseif ($redirectTo === 'viewlist') {
            //     return redirect()->route('blog-list');
            // }
            // return redirect()->route('blog-list');
            return redirect()->back();
        }
        return view('blog.blog-add');
    }
    public function fblogmember(Request $request)
    {
        $fblogs = Fblog::all();

        return view("blog.fblog-member", ['fblogs' => $fblogs]);
    }
    public function sblogvoucher(Request $request)
    {
        $sblogs = sblog::all();
        return view("blog.sblog-voucher", ['sblogs' => $sblogs]);
    }
    public function fblogadduser(Request $request)
    {
        $fblogs = [];
        $fblogs['title'] = "This is my login Index page";
        $request->session();
        if ($request->isMethod("post")) {
            $input = [
                'user_group' => $request->input('user_group'),
                'agency' => $request->input('agency'),
                'first_name' => $request->input('first_name'),
                'last_name' => $request->input('last_name'),
                'email' => $request->input('email'),
                'contact' => $request->input('contact'),
                'status' => $request->input('status'),
            ];
            $fblogs = Fblog::insert($input);
            if ($fblogs) {
                $request->session()->flash('flash_notification.success', '<strong>Congratulations</strong>');
                return redirect("fblog/member");
            } else {
                die('Input data not found');
                exit;
            }
        }
        $fblogs = Fblog::all();
        return view("blog.fblog-adduser", ['fblogs' => $fblogs]);
    }
    public function fblogedit(Request $request)
    {
        $fblog = Fblog::find($request->id);
        if (!$fblog) {
            return redirect('fblog/edit')->withErrors('Blog entry not found.');
        }
        if ($request->isMethod('post')) {
            $fblog->update([
                'user_group' => $request->input('user_group'),
                'agency' => $request->input('agency'),
                'first_name' => $request->input('first_name'),
                'last_name' => $request->input('last_name'),
                'email' => $request->input('email'),
                'contact' => $request->input('contact'),
                'status' => $request->input('status'),
            ]);
            return redirect('fblog/member');
        }
        return view("blog.fblog-edit", ['fblog' => $fblog]);
    }
    public function fblogdelete($id)
    {
        $fblog = Fblog::findOrFail($id);
        $fblog->delete();
        return redirect()->route('fblog-member');
    }
    public function blogchart(Request $request)
    {
        if ($request->isMethod("post")) {
            $validatedData = $request->validate([
                'title' => 'required|string|max:255',
                'description' => 'required|string',
                'image' => 'nullable|mimes:png,jpg,jpeg,webp',
                'status' => 'required|in:Active,Inactive',
            ]);
            $data = $request->only(['title', 'description', 'status']);
            if ($request->hasFile('image')) {
                try {
                    $image = $request->file('image');
                    $imageName = time() . '.' . $image->getClientOriginalExtension();
                    $image->move(public_path('public/upload/blog'), $imageName);
                    $data['image'] = 'public/upload/blog' . $imageName;
                } catch (\Exception $e) {
                    return back()->withErrors(['image' => 'Image upload failed: ' . $e->getMessage()]);
                }
            } else {
                $data['image'] = null;
            }
            Blog::create($data);
            return redirect()->route('blog-chart')->with('success', 'Blog added successfully!');
        }
        $blogs = Blog::all();
        return view("blog.blog-chart", ['blogs' => $blogs]);
    }
    public function blogIndex(Request $request)
    {
        $data = [];
        $data['title'] = "This is my login Index page";
        $request->session();
        if ($request->isMethod("post")) {
            $input = [
                'title' => $request->input('title'),
            ];
            $dataInput = Blog::insert($input);
            if ($dataInput) {
                $request->session()->flash('flash_notification.primary', '<strong>Thank You!</strong>, Your Registration Form is successfully Submitted.');

                return redirect("pricing");
            } else {
                return redirect("crud");
            }
        }
        $data['world'] = Blog::where(['status' => 'active', 'type' => 'world'])->select('image', 'title', 'description')->first();
        $data['design'] = Blog::where(['status' => 'active', 'type' => 'design'])->select('image', 'title', 'description')->first();
        $data['page'] = Blog::where(['status' => 'active', 'type' => 'page'])->select('image', 'title', 'description')->first();
        $data['page5'] = Blog::where(['status' => 'active', 'type' => 'page5'])->select('image', 'title', 'description')->first();
        $data['page6'] = Blog::where(['status' => 'active', 'type' => 'page6'])->select('image', 'title', 'description')->first();
        $data['page'] = Fblog::where(['status' => 'active', 'type' => 'page'])->select('user_group')->get();
        $data['page1'] = Fblog::where(['status' => 'active', 'type' => 'page1'])->select('user_group')->get();
        $data['page2'] = Fblog::where(['status' => 'active', 'type' => 'page2'])->select('user_group')->get();
        $data['page3'] = Fblog::where(['status' => 'active', 'type' => 'page3'])->select('user_group')->get();
        $data['page4'] = Fblog::where(['status' => 'active', 'type' => 'page4'])->select('user_group')->get();
        $data['page7'] = Fblog::where(['status' => 'active', 'type' => 'page7'])->select('user_group')->get();
        $data['page8'] = Fblog::where(['status' => 'active', 'type' => 'page8'])->select('user_group')->get();
        $data['page9'] = Fblog::where(['status' => 'active', 'type' => 'page9'])->select('user_group')->get();
        $data['code'] = sblog::where(['status' => 'active', 'type' => 'code'])->select('image', 'promotion', 'title')->get();
        return view("blog.blog", ['data' => $data]);
    }
    public function fblogIndex(Request $request)
    {
        $data = [];
        $data['title'] = "This is my login Index page";
        $request->session();
        if ($request->isMethod("post")) {
            $input = [
                'title' => $request->input('title'),
            ];
            $dataInput = Blog::insert($input);
            if ($dataInput) {
                $request->session()->flash('flash_notification.primary', '<strong>Thank You!</strong>, Your Registration Form is successfully Submitted.');

                return redirect("pricing");
            } else {
                return redirect("crud");
            }
            echo '<pre>';
            print_r($input);
            exit;
            die('die here');
            exit;
        }
        return view("fblog.fblog", ['data' => $data]);
    }
    public function up()
    {
        Blog::table('blogs', function (Blog $table) {
            $table->string('image')->nullable();
        });
    }
    public function down()
    {
        Blog::table('blogs', function (Blog $table) {
            $table->dropColumn('image');
        });
    }
    public function blogEdit(Request $request, $id)
    {
        $blog = Blog::findOrFail($id);
        if ($request->isMethod('post')) {
            $input = $request->except(["_token"]);
            if ($request->hasFile('image')) {
                $image = $request->file('image');
                $imageName = date('d') . time() . '.' . $image->getClientOriginalExtension();
                $image->move(public_path('upload/blog'), $imageName);
                $input['image'] = $imageName;
            }
            Blog::where(["id" => $id])->update($input);
            return redirect()->route('blog-list');
        }
        return view('blog.blog-edit', compact('blog'));
    }
    public function Blogdelete($id)
    {
        $blog = Blog::findOrFail($id);
        $blog->delete();
        return redirect()->route('blog-list');
    }
    public function bloghome(Request $request)
    {
        $data = [];
        $data['admin'] = Blog::where(['status' => 'active', 'type' => 'bloghome'])->select('image', 'id')->get();
        $data['title'] = "This is my First Blog page";
        $blogList = Blog::where(["count_status" => "1"])->count();
        $fblogmember = Fblog::where(["count_status" => "1"])->count();
        $sblogvoucher = sblog::where(["count_status" => "1"])->count();
        $data['count_status'] = $blogList;
        $data['blogmember'] = $fblogmember;
        $data['blogvoucher'] = $sblogvoucher;
        return view("blog.blog-home", ['data' => $data]);
    }
    public function loginIndex(Request $request)
    {
        if ($this->isLogged()) {
            return to_route('index');
        }
        $data = [];
        $data['title'] = "This is my Login and Register Page";

        if ($request->isMethod('post')) {
            $email = $request->input('email');
            $password = $request->input('password');
            if (Auth::attempt(['email' => $email, 'password' => $password])) {
                return redirect('/')->with('flash_notification.success', 'Login successful.');
            } else {
                $request->session()->flash('flash_notification.error', '<strong>Error:</strong> Invalid login credentials.');
                return redirect('login');
            }
        }
        return view("login.login", ['data' => $data]);
    }
    public function blogforget(Request $request)
    {
        $data = [];
        $id = $request->email;
        if ($request->isMethod('post')) {
            die('die here');
            exit;
            $email = User::where(['email' => $request->$id]);
        }
        return view("blog.blog-forget", ['data' => $data]);
    }
    public function blogforgetEmail(Request $request)
    {
        $data = [];
        if ($request->isMethod('post')) {
            $emailValidate = $request->input('email');
            $check = User::where(['email' => $emailValidate])->first();
            if (!empty($check)) {
                $input = [
                    'email' => $request->input('email'),
                    'password' => password_hash($request->input('confirm-password'), PASSWORD_DEFAULT),
                ];
                $email = User::where(['email' => $emailValidate])->update($input);
                return redirect("login");
            } else {
                die('Email not correct');
                exit;
                return false;
            }
        }
        return view("blog.blog-forget", ['data' => $data]);
    }
    public function registerIndex(Request $request)
    {
        $data = [];
        $data['title'] = "This is my login Index page";
        $request->session()->flash('success', 'Employee submitted successfully!');
        if ($request->isMethod("post")) {
            $input = [
                'full_name' => $request->input('full_name'),
                'dob' => $request->input('date_of_birth'),
                'email' => $request->input('email'),
                'contact' => $request->input('contact'),
                'password' => password_hash($request->input('password'), PASSWORD_DEFAULT)
            ];
            $dataInput = User::insert($input);
            if ($dataInput) {
                $request->session()->flash('flash_notification.success', '<strong>Congratulations</strong>, Your Registration Detail is successfully Submitted.');
                return redirect("/");
            } else {
                die('Input data not found');
                exit;
            }
        }
        return view("login.register", ['data' => $data]);
    }
    public function logoutIndex(Request $request)
    {
        Auth::logout();
        return redirect('login')->with('success', 'You have been logged out successfully.');
    }
    public function detailIndex()
    {
        $data = [];
        $data['title'] = "This is my detail Index page";
        $data['user'] = User::select('id', 'full_name', 'dob', 'email', 'contact', 'password')->paginate(10);
        return view("detail.detail", ['data' => $data]);
    }
    public function edit(Request $request)
    {
        $data = [];
        $id = $request->id;
        $data['title'] = "Edit Details";
        $data['user'] = User::where(['id' => $id])->select('id', 'full_name', 'email', 'password')->first();
        if ($request->isMethod('post')) {
            $input = [
                'full_name' => $request->input('full_name'),
                'email' => $request->input('email'),
                'password' => $request->input('password')
            ];
            $dataInput = User::where(['id' => $id])->update($input);
            if ($dataInput) {

                return redirect("detail");
            } else {
                die('die here');
                exit;
            }
        }
        return view("detail.edit", ['data' => $data]);
    }
    public function delete(Request $request)
    {
        $data = [];
        $id = $request->id;
        $delete = User::where(['id' => $id])->delete();
        return redirect("detail");
    }
    public function blog(Request $request)
    {
        $data = [];
        $id = $request->id;
        $blog = User::where(['id' => $id])->blog();
        return view("detail.detail", ['data' => $data]);
    }
    public function homeIndex(Request $request)
    {
        $data = [];
        $id = $request->id;
        $home = User::where(['id' => $id])->home();
        return view("home", ['data' => $data]);
    }
    public function informationIndex(Request $request)
    {
        $data = [];
        return view("home.information", ['data' => $data]);
    }
    public function formIndex(Request $request)
    {
        $data = [];
        // die ('die here'); exit;
        return view("form", ['data' => $data]);
    }
    public function features(Request $request)
    {
        $data = [];
        $id = $request->id;
        $fetures = User::where(['id' => $id])->feature();
        return view("detail.detail", ['data' => $data]);
    }
    public function pricing(Request $request)
    {
        $data = [];
        $id = $request->id;
        $pricing = User::where(['id' => $id])->pricing();
        return view("detail.detail", ['data' => $data]);
    }
    public function applicationIndex(Request $request)
    {
        $data = [];
        $id = $request->id;
        if ($request->isMethod('post')) {
            $input = [
                'title' => $request->input('title'),
                'status' => $request->input('status'),
                'input_name' => $request->input('input_name'),
                'input_id' => $request->input('input_id'),
                'site_location' => $request->input('site_location'),
                'type' => $request->input('type'),
            ];
            $dataInput = Input::insert($input);
        }
        return view("home.application", ['data' => $data]);
    }
    public function applicationDetail(Request $request)
    {
        $data = [];
        $data['input'] = Input::select('id', 'title', 'input_id', 'input_name', 'status', 'site_location', 'type')->get();
        $data['multi'] = Input::where(['site_location' => 'as'])->select('id', 'title', 'input_id', 'input_name', 'status', 'site_location', 'type')->get();
        return view("home.application-detail", ['data' => $data]);
    }
    public function pricingIndex(Request $request)
    {
        $data = [];
        $id = $request->id;
        return view("home.pricing", ['data' => $data]);
    }
    public function featuresIndex(Request $request)
    {
        $data = [];
        $id = $request->id;
        return view("home.features", ['data' => $data]);
    }
    public function servicesIndex(Request $request)
    {
        $data = [];
        return view("home.services", ['data' => $data]);
    }
    public function aboutIndex(Request $request)
    {
        $data = [];
        return view("home.about", ['data' => $data]);
    }
    public function blogpage(Request $request)
    {
        $data = [];
        $id = $request->id;
        $data['b_page'] = sblog::where(['id' => $id, 'status' => 'active'])->select('promotion', 'title', 'image')->first();
        return view("blog.blog-page", ['data' => $data]);
    }
    public function blogpage1(Request $request)
    {
        $data = [];
        return view("blog.blog-page1", ['data' => $data]);
    }
    public function blogpage2(Request $request)
    {
        $data = [];
        return view("blog.blog-page2", ['data' => $data]);
    }
    public function blogread(Request $request)
    {
        $data = [];
        $data['code2'] = Blog::where(['status' => 'active', 'type' => 'viewblog'])->select('image', 'title', 'description', 'id')->get();
        return view("blog.blog-read", ['data' => $data]);
    }
    public function blogpage4(Request $request)
    {
        $data = [];
        $id = $request->id;
        $data['b_page1'] = Blog::where(['id' => $id, 'status' => 'active'])->select('description', 'title', 'image')->first();
        return view("blog.blog-page4", ['data' => $data]);
    }
    public function contactIndex(Request $request)
    {
        $data = [];
        return view("includes.contact");
    }
    public function storeIndex(Request $request)
    {
        $data = [];
        return view("includes.store");
    }
    public function onlineIndex(Request $request)
    {
        $data = [];
        return view("includes.online");
    }
    public function uploadAvatar(Request $request)
    {
        $request->validate([
            'avatar' => 'required|image|mimes:jpeg,png,jpg,gif|max:2048',
        ]);

        $user = auth()->user();
        $fileName = time() . '.' . $request->avatar->extension();
        $request->avatar->move(public_path('upload/blog'), $fileName);

        $user->avatar = 'upload/blog/' . $fileName;
        $user->save();

        return back();
    }
    public function deleteAvatar()
    {
        $user = auth()->user();
        if ($user->avatar && file_exists(public_path($user->avatar))) {
            unlink(public_path($user->avatar));
        }
        $user->avatar = null;
        $user->save();
        return back();
    }
}
