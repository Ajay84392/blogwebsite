<?php
namespace App\Http\Controllers;
use App\Models\Customer;
use Illuminate\Http\Request;
use Auth;

class Customercontroller extends Controller
{
    public function customerIndex(Request $request)
    {
        $data = [];
        $data['title'] = "This is my Login and Register Page";
        if ($request->isMethod('post')) {
            $email = $request->input('email');
            $password = $request->input('password');
            if (Auth::attempt(['email' => $email, 'password' => $password])) {
                return redirect('/')->with('flash_notification.success', 'Login successful.');
            } else {
                $request->session()->flash('flash_notification.error', '<strong>Error:</strong> Invalid login credentials.');
                return redirect('customer');
            }
        }
        return view("login.customer", ['data' => $data]);
    }
    public function newcustomer(Request $request)
    {
        $data = [];
        $data['title'] = "This is my login Index page";
        $request->session()->flash('success', 'Employee submitted successfully!');
        if ($request->isMethod("post")) {
            $input = [
                'full_name' => $request->input('full_name'),
                'dob' => $request->input('date_of_birth'),
                'email' => $request->input('email'),
                'contact' => $request->input('contact'),
                'password' => password_hash($request->input('password'), PASSWORD_DEFAULT)
            ];
            $dataInput = User::insert($input);
            if ($dataInput) {
                $request->session()->flash('flash_notification.success', '<strong>Congratulations</strong>, Your Registration Detail is successfully Submitted.');
                return redirect("/");
            } else {
                die('Input data not found');
                exit;
            }
        }
        return view("login.new-customer", ['data' => $data]);
    }
    public function forgetcustomer(Request $request)
    {
        $data = [];
        $id = $request->email;
        if ($request->isMethod('post')) {
            die('die here');
            exit;
            $email = User::where(['email' => $request->$id]);
        }
        return view("blog.forget-customer", ['data' => $data]);
    }
}
