<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class Fblog extends Model
{
    protected $fillable = [
        'user_group',
        'agency',
        'first_name',
        'last_name',
        'last_name',
        'email',
        'contact',
        'status',
    ];
}
