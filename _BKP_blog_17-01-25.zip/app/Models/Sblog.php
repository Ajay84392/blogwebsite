<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;

use Illuminate\Database\Eloquent\Model;

class Sblog extends Model
{
    use HasFactory;
    protected $table = 'sblogs';

    protected $fillable = [
        'promotion',
        'title',
        'image',

    ];
}
