<?php
namespace App\Helpers;
use Auth;
use GuzzleHttp\Psr7\Request;
class Helper
{
    public static function isLogged()
    {
        if (Auth::check()) {
            return true;
        }
        return false;
    }
    public static function getUserName()
    {
        return Auth::check() ? Auth::user()->full_name : "";
    }
    public static function getAvatar()
    {
        return Auth::check() ? Auth::user()->avatar : "";
    }
}
