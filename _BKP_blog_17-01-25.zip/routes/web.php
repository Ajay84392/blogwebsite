<?php

use App\Http\Controllers\Controller;
use App\Http\Controllers\CrudController;
use App\Http\Controllers\customercontroller;
use App\Http\Controllers\HomeController;
use App\Http\Middleware\UserAuth;
use Illuminate\Support\Facades\Route;

// Customer details routes ----------
Route::any('new/customer', [Customercontroller::class, 'newcustomer'])->name('new-customer');
Route::any('customer', [Customercontroller::class, 'customerIndex'])->name('customer');
Route::get('forget/customer', [customercontroller::class, 'forgetcustomer'])->name('forget-customer');

// user login details routes ---------
Route::any('delete-avatar', [HomeController::class, 'deleteavatar'])->name('delete-avatar');
Route::any('upload-avatar', [HomeController::class, 'uploadavatar'])->name('upload-avatar');
Route::any('register', [HomeController::class, 'registerIndex'])->name('register');
Route::any('login', [HomeController::class, 'loginIndex'])->name('login');
Route::any('logout', [HomeController::class, 'logoutIndex'])->name('logout');
Route::any('detail', [HomeController::class, 'detailIndex'])->name('detail')->middleware('user-auth');
Route::any('edit/{id}', [HomeController::class, 'edit'])->name('edit');
Route::any('delete/{id}', [HomeController::class, 'delete'])->name('delete');
Route::get('blog/forget', [HomeController::class, 'blogforget'])->name('blog-forget');
Route::any('form', [HomeController::class, 'formIndex'])->name('form');

// footer details routes -----------
Route::any('store', [HomeController::class, 'storeIndex'])->name('store');
Route::any('online', [HomeController::class, 'onlineIndex'])->name('online');
Route::any('contact', [HomeController::class, 'contactIndex'])->name('contact');
Route::any('home', [HomeController::class, 'homeIndex'])->name('home');
Route::any('information', [HomeController::class, 'informationIndex'])->name('information');
Route::any('features', [HomeController::class, 'featuresIndex'])->name('features');
Route::any('pricing', [HomeController::class, 'pricingIndex'])->name('pricing');
Route::any('application', [HomeController::class, 'applicationIndex'])->name('application');
Route::any('application/detail', [HomeController::class, 'applicationDetail'])->name('application-detail');
Route::any('pricing', [HomeController::class, 'pricingIndex'])->name('pricing');
Route::any('services', [HomeController::class, 'servicesIndex'])->name('services');
Route::any('about', [HomeController::class, 'aboutIndex'])->name('about');

// blog admin section routes ---------
Route::any('/', [HomeController::class, 'index'])->name('index');
Route::any('/blog/status-toggle/{id}', [HomeController::class, 'toggleStatus'])->name('blog-status-toggle');
Route::any('blog/add', [HomeController::class, 'blogadd'])->name('blog-add');
Route::any('blog/reservation', action: [HomeController::class, 'blogreservation'])->name('blog-reservation');
Route::any('blog/chart', action: [HomeController::class, 'blogchart'])->name('blog-chart');
Route::any('blog', [HomeController::class, 'blogIndex'])->name('blog');
Route::any('blog/edit/{id}', [HomeController::class, 'blogEdit'])->name('blog-edit');
Route::any('blog/delete/{id}', [HomeController::class, 'blogDelete'])->name('blog-delete');

// blog databases control section routes -----------
Route::post('blog/forget/email', [HomeController::class, 'blogforgetEmail'])->name('blog-forget-email');
Route::any('blog/voucher', [HomeController::class, 'blogvoucher'])->name('blog-voucher');
Route::any('blog/submitforgot', [HomeController::class, 'blogsubmitforgot'])->name('blog-submitforgot');
Route::any('blog/sendResetLink', [HomeController::class, 'blogsendResetLink'])->name('blog-sendResetLink');
Route::any('blog/page/{id}', action: [HomeController::class, 'blogpage'])->name('blog-page');
Route::any('blog/page1', action: [HomeController::class, 'blogpage1'])->name('blog-page1');
Route::any('blog/page2', action: [HomeController::class, 'blogpage2'])->name('blog-page2');
Route::any('blog/page4', action: [HomeController::class, 'blogpage4'])->name('blog-page4');
Route::any('blog/read', action: [HomeController::class, 'blogread'])->name('blog-read');
Route::any('blog/list', [HomeController::class, 'bloglist'])->name('blog-list');
Route::any('blog/view', action: [HomeController::class, 'blogview'])->name('blog-view');
Route::any('blog/learn', action: [HomeController::class, 'bloglearn'])->name('blog-learn');

// fblog file in database routes --------
Route::any('fblog/adduser', action: [HomeController::class, 'fblogadduser'])->name('fblog-adduser');
Route::any('fblog', [HomeController::class, 'fblogIndex'])->name('fblog');
Route::any('fblog/member', [HomeController::class, 'fblogmember'])->name('fblog-member');
Route::any('fblog/edit', [HomeController::class, 'fblogedit'])->name('fblog-edit');
Route::any('fblog/delete/{id}', [HomeController::class, 'fblogdelete'])->name('fblog-delete');

// sblog file in database routes -------
Route::any('sblog/edit/{id}', [HomeController::class, 'sblogedit'])->name('sblog-edit');
Route::any('sblog/delete/{id}', [HomeController::class, 'sblogdelete'])->name('sblog-delete');
Route::any('sblog/voucher', [HomeController::class, 'sblogvoucher'])->name('sblog-voucher');
Route::any('sblog/addvoucher', [HomeController::class, 'sblogaddvoucher'])->name('sblog-addvoucher');

// crud opration routes -------
Route::any('crud', [CrudController::class, 'crudIndex'])->name('crud');
Route::any('crud/detail', [CrudController::class, 'crudDetail'])->name('crud-detail');
Route::any('crud/edit/{id}', [CrudController::class, 'crudEdit'])->name('crud-edit');
Route::any('crud/delete', [CrudController::class, 'cruddelete'])->name('crud-delete');

// middleware routes ---------------
Route::middleware(['user-auth', UserAuth::class])->group(function () {
Route::any('crud', [CrudController::class, 'crudIndex'])->name('crud');
Route::any('crud/detail', [CrudController::class, 'crudDetail'])->name('crud-detail');
Route::any('crud/edit/{id}', [CrudController::class, 'crudEdit'])->name('crud-edit');
Route::any('crud/delete', [CrudController::class, 'cruddelete'])->name('crud-delete');
Route::any('blog/home', [HomeController::class, 'bloghome'])->name('blog-home');
});
