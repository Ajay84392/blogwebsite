<!doctype html>
<html lang="en">
<head>
    <title>Title</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous" />
    <link rel="stylesheet" href="{{ asset('./public/template/frontend_css.css') }}">
</head>
<body>
    <main>
        @if (session('flash_notification.success'))
            <div class="alert alert-success flash-message">
                {!! session('flash_notification.success') !!}
            </div>
        @endif

        @if (session('flash_notification.error'))
            <div class="alert alert-danger flash-message">
                {!! session('flash_notification.error') !!}
            </div>
        @endif
        <div>
            <img src="{{ asset('public/image/abc6.webp') }}" class="d-block" alt="..."
                style="height: 800px; width: 100%;">
        </div>
        <div class="card-img-overlay mt-5">
            <div class="card bg-white center mt-5"
                style="border-radius:12px; height:fit-content; width: 30rem;margin-left:auto;margin-right:auto;">
                <div class="card-body">
                    <form action="{{ url(URL::current()) }}" method="post" class="needs-validation"
                        autocomplete="new-password" novalidate>
                        @csrf
                        <div class="d-flex justify-content-center ">
                            <img src="{{ asset('public/image/abc4.jpg') }}" class="d-block" alt="..."
                            style="height:100px;width:10rem;">
                        </div>
                        <div class="">
                            <i class="bi fs-5 bi-envelope-fill"></i>
                            <label for="exampleFormControlInput2" class="mt-2 h6  form-label">Email Id</label>
                            <input type="email" class="form-control" id="email" name="email"
                                autocomplete="new-password" placeholder="name@example.com">
                            <div class="invalid-feedback">
                                * Required Field.
                            </div>
                        </div>
                        <div class="mb-3 mt-2">
                            <i class="bi fs-5 bi-lock-fill"></i>
                            <label for="exampleFormControlTextarea1" class="mt-3 h6 form-label">Password</label>
                            <input type="password" class="form-control" id="password" name="password"
                                autocomplete="new-password" rows="3">
                            <div class="invalid-feedback">
                                *Your password must be 8-20 characters long, contain letters and numbers, and must not
                                contain spaces, special characters.
                            </div>
                        </div>
                        <div class="text-center">
                            <button type="Login" class="mt-3 bg-dark form-control btn btn-primary">Submit</button>
                        </div>
                        <div class="mt-2 form-check d-flex align-items-center justify-content-between">
                            <div class="d-flex align-items-center">
                                <a href="{{ 'register' }}" class="no-underline text-primary" aria-current="page">New Register</a>
                            </div>
                            <a href="{{ route('blog-forget') }}" class="text-primary">Forgot Password ?</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </main>
    <footer>
    </footer>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"
        integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous">
    </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js"
        integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+" crossorigin="anonymous">
    </script>

    <script>
        document.getElementById('name').addEventListener('blur', function() {
            if (this.value.trim() === '') {
                this.classList.add('is-invalid');
            } else {
                this.classList.remove('is-invalid');
            }
        });
    </script>
    <script>
        document.getElementById('email').addEventListener('blur', function() {
            if (this.value.trim() === '') {
                this.classList.add('is-invalid');
            } else {
                this.classList.remove('is-invalid');
            }
        });
    </script>
    <script>
        document.getElementById('password').addEventListener('blur', function() {
            if (this.value.trim() === '') {
                this.classList.add('is-invalid');
            } else {
                this.classList.remove('is-invalid');
            }
        });
    </script>
    <script>
        setTimeout(() => {
            document.getElementById("alert").style.display = "none";
        }, 5000);
    </script>
    <script>
        setTimeout(() => {
            const flashMessages = document.querySelectorAll('.flash-message');
            flashMessages.forEach(msg => msg.style.display = 'none');
        }, 10000); 
    </script>
</body>
</html>
