<!doctype html>
<html lang="en">
<head>
    <title>Title</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous" />
    <link rel="stylesheet" href="{{ asset('./public/template/frontend_css.css') }}">
</head>
<body>
    <main>
        @if (session()->has('error'))
            <div class="alert alert-danger" id="alert">{{ session('error') }}</div>
        @endif
        <div>
            <img src="{{ asset('public/image/abc6.webp') }}" class="d-block" alt="..."
                style="height: 800px; width: 100%;">
        </div>
        <div class="card-img-overlay mt-5">
            <div class="card bg-white center mt-5"
                style="border-radius:12px; height:fit-content; width: 30rem;margin-left:auto;margin-right:auto;">
                <div class="card-body">
                    <form action="{{ URL::current() }}" method="post" class="needs-validation"
                        autocomplete="new-password" novalidate>
                        @csrf
                        <div class="d-flex justify-content-center ">
                            <img src="{{ asset('public/image/abc4.jpg') }}" class="d-block" alt="..."
                            style="height:100px;width:10rem;">
                        </div>
                        <div class="mb-3 mt-2">
                            <i class="bi fs-5 bi-person-circle"></i>
                            <label for="exampleFormControlInput1" class="h6 form-label">Full Name</label>
                            <input type="text" class="form-control" id="full_name" name="full_name"
                                placeholder="Your Name">
                            <div class="invalid-feedback">
                                * Required Field.
                            </div>
                        </div>
                        <div class="mb-3 mt-2">
                            <i class="bi fs-5 bi-person-circle"></i>
                            <label for="exampleFormControlInput1" class="h6 form-label">Date of Birth</label>
                            <input type="date" class="form-control" id="date_of_birth" name="date_of_birth"
                                placeholder="Enter D.O.B">
                            <div class="invalid-feedback">
                                * Required Field.
                            </div>
                        </div>
                        <div class="">
                            <i class="bi fs-5 bi-envelope-fill"></i>
                            <label for="exampleFormControlInput2" class="mt-2 h6  form-label">Email address</label>
                            <input type="email" class="form-control" id="email" name="email"
                                autocomplete="new-password" placeholder="name@example.com">
                            <div class="invalid-feedback">
                                * Required Field.
                            </div>
                        </div>
                        <div class="">
                            <i class="bi fs-5 bi-envelope-fill"></i>
                            <label for="exampleFormControlInput2" class="mt-2 h6  form-label">Contact</label>
                            <input type="number" class="form-control" id="contact" name="contact"
                                autocomplete="new-password" placeholder="Contact Number">
                            <div class="invalid-feedback">
                                * Required Field.
                            </div>
                        </div>
                        <div class="mb-3 mt-2">
                            <i class="bi fs-5 bi-lock-fill"></i>
                            <label for="exampleFormControlTextarea1" class="mt-3 h6 form-label">Password</label>
                            <input type="password" class="form-control" id="password" name="password"
                                autocomplete="new-password" rows="3">
                            <div class="invalid-feedback">
                                *Your password must be 8-20 characters long, contain letters and numbers, and must not
                                contain spaces, special characters.
                            </div>
                        </div>
                        <div class="text-center">
                            <button type="Login" class="mt-3 bg-dark form-control btn btn-primary">Register</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </main>
    <footer>
    </footer>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"
        integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous">
    </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js"
        integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+" crossorigin="anonymous">
    </script>

    <script>
        document.getElementById('name').addEventListener('blur', function() {
            if (this.value.trim() === '') {
                this.classList.add('is-invalid');
            } else {
                this.classList.remove('is-invalid');
            }
        });
    </script>
    <script>
        document.getElementById('email').addEventListener('blur', function() {
            if (this.value.trim() === '') {
                this.classList.add('is-invalid');
            } else {
                this.classList.remove('is-invalid');
            }
        });
    </script>
    <script>
        document.getElementById('contact').addEventListener('blur', function() {
            if (this.value.trim() === '') {
                this.classList.add('is-invalid');
            } else {
                this.classList.remove('is-invalid');
            }
        });
    </script>
    <script>
        document.getElementById('password').addEventListener('blur', function() {
            if (this.value.trim() === '') {
                this.classList.add('is-invalid');
            } else {
                this.classList.remove('is-invalid');
            }
        });
    </script>
    <script>
        setTimeout(() => {
            document.getElementById("alert").style.display = "none";
        }, 5000);
    </script>
</body>
</html>