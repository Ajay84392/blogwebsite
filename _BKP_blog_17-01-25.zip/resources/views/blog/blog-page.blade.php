@extends('layout.default')
@section('content')
    <p class="h2 mx-5 mt-4">Templates</p>
    {{-- <p class="h2 mx-5 mt-4">Website builder</p> --}}
    <div class="mt-3">
        <i class="bi mx-5 bi-person"> Aigars</i>
        <i class="bi bi-chat-left"> Blog, fashion, personal Website templates, Travel</i>
        <i class="mx-5 bi bi-chat"> 0 Comments</i>
    </div>

    <div class="container mt-3">
        @php 
        // echo '<pre>';
        // print_r($data['b_page']->image);exit;
        @endphp
        <img src="{{ asset('public/upload/blog/'.$data['b_page']->image) }}" class="d-block" alt="Template Preview"
            style="height: 600px; width: 100%;">

        <div class="row mt-4">
            <div class="col-md-6">
                <p class="h2" style="text-decoration: underline; text-decoration-color: blue;">Template Details</p>
                <div class="d-flex">
                    <p class="h5 mt-2 mx-2">Author:</p>
                    <p class="mt-2">Colorlib</p>
                </div>
                <div class="d-flex">
                    <p class="h5 mx-2">Released:</p>
                    <p class="mt-1">January 2025</p>
                </div>
                <div class="d-flex">
                    <p class="h5 mx-2">Licence:</p>
                    <p class="mt-1">MIT</p>
                </div>
                <div class="d-flex">
                    <p class="h5 mx-2">Credits:</p>
                    <p class="mt-1">Images from Unsplash</p>
                </div>
            </div>

            <div class="col-md-6">
                <p class="h2" style="text-decoration: underline; text-decoration-color: blue;">Description</p>
                <p class="mt-3">
                    Philosophy is a blog template well suited for lifestyle, fashion, food, personal, design, or any other awesome blog. Its beautiful grid layout will help your blog stand out.</p>
                    <p class="mt-3">It is a simple HTML template without a content management system or admin dashboard. If you are looking for something more beginner-friendly, here are the best WordPress themes for bloggers. WordPress is not only the most popular CMS but also the easiest one to use.</p>
            </div>
        </div>
        <button type="submit" class="btn btn-warning mx-3 mb-4" style="height:60px; width: 160px;"><i class="mx-2 bi bi-eye"></i> Preview</button>
    <p class="h2 mt-2">Share This</p>
    <button type="submit" class="mt-4 btn btn-primary mx-3 mb-5" style="height:60px; width: 160px;"><i class="bi bi-facebook"></i> Facebook</button>
    <button type="submit" class="mt-4 btn btn-dark mx-3 mb-5" style="height:60px; width: 160px;"><i class="bi bi-twitter-x"></i> Twitter</button>
    <button type="submit" class="mt-4 btn btn-danger mx-3 mb-5" style="height:60px; width: 160px;"><i class="bi bi-pinterest"></i> Pinterest</button>
    <button type="submit" class="mt-4 btn btn-primary mx-3 mb-5" style="height:60px; width: 160px;"><i class="bi bi-linkedin"></i> Linkedin</button>
    </div>
@endsection
