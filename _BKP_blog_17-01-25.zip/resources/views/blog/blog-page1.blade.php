@extends('layout.default')
@section('content')
    <div class="container mt-5">
        <div class="row">
            <div class="col">

                <main class="container">
                    
                    <img src="{{ asset('public/image/abc36.webp') }}" class="mt-3 d-block" alt="..."
                                    style="height: 400px; width: 100%;">
                </main>
                <hr class="featurette-divider">
                <div class="row featurette">
                    <div class="col-md-7">
                        <h2 class="featurette-heading fw-normal lh-1">First featurette heading. <span
                                class="text-body-secondary">It’ll blow your mind.</span></h2>
                        <p class="lead">Your content. And yes, this is the last block of representative placeholder content.
                            Again, not really intended to be actually read, simply here to give you a better view of
                            what this would look like with some actual content. Your content. If you’re just starting a blog, you're probably asking yourself—What should I write about?


                            Before you dive into writing, you’ll need to select a niche. Pick one overarching theme in a particular field for your blog to attract a targeted group of fans.
                            
                            
                            Start with your passions when selecting your niche—after all, you’ll dedicate lots of time and effort to this subject. But if you seriously want to make money blogging, you also need to think about what subjects people will want to read about, and if those subjects are financially viable. 
                            
                            
                            Look at Cup of Jo, for example, a daily women’s lifestyle site that explores topics like food, culture, style, travel, relationships and parenting. Founded in 2007, the popular blog “receives over 4 million monthly page views and almost 1 million monthly unique visitors,” according to the site. By narrowing in on a specific niche and providing relevant and relatable content to the right audience, founder Joanna Goddard has cultivated a strong community and deeply engaged readership. </p>
                    </div>
                    <div class="col-md-5">
                        <img src="{{ asset('public/image/abc13.webp') }}" class="d-block" alt="..."
                        style="height:500px;width:500px;">
                    </div>
                </div>

                <hr class="featurette-divider">
                <div class="row featurette">
                    <div class="col-md-7 order-md-2">
                        <h2 class="featurette-heading fw-normal lh-1">Oh yeah, it’s that good. <span
                                class="text-body-secondary">See for yourself.</span></h2>
                        <p class="lead">Another featurette? Of course. More placeholder content here to give you
                            an idea of how this layout would work with some actual real-world content in place And yes, this is the last block of representative placeholder content.
                            Again, not really intended to be actually read, simply here to give you a better view of
                            what this would look like with some actual content. Your content And yes, this is the last block of representative placeholder content.
                            Again, not really intended to be actually read, simply here to give you a better view of
                            what this would look like with some actual content. Your content.</p>
                    </div>
                    <div class="col-md-5 order-md-1">
                        <img src="{{ asset('public/image/abc17.webp') }}" class="d-block" alt="..."
                        style="height:500px;width:500px;">
                    </div>
                </div>

                <hr class="featurette-divider">
                <div class="row featurette">
                    <div class="col-md-7">
                        <h2 class="featurette-heading fw-normal lh-1">And lastly, this one. <span
                                class="text-body-secondary">Checkmate.</span></h2>
                        <p class="lead">And yes, this is the last block of representative placeholder content.
                            Again, not really intended to be actually read, simply here to give you a better view of
                            what this would look like with some actual content. Your content. Making money blogging sounds like a dream. Not only do you get to work independently and skip the 9-to-5, but you can also blog from anywhere in the world about the topics of your choice. While it involves hard work, even beginners can achieve this with the right strategy.


                            You’ll need to create a blog, of course, in order to become a part of the blogosphere. After that, you’ll need to grow your audience. Whether you want a side hustle or a career, this comprehensive guide will walk you through actionable steps on how to make a blog, build your readership and grow your blog. Then, you’ll learn about using the robust tools that can help you learn how to make money blogging, turning your website traffic into money and potentially starting a business online.</p>
                    </div>
                    <div class="col-md-5">
                        <img src="{{ asset('public/image/abc11.webp') }}" class="d-block" alt="..."
                        style="height:500px;width:500px;">
                    </div>
                </div>
                <hr class="featurette-divider">
            </div>
            </main>
            <script src="/docs/5.3/dist/js/bootstrap.bundle.min.js"
                integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous">
            </script>
            </body>
            </html>
        </div>
    </div>
</div>
            </div>
        </div>
    </div>
@endsection
@section('css')
@endsection
@section('script')
@endsection
