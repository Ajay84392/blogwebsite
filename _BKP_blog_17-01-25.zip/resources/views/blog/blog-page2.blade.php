{{-- @extends('layout.default')
@section('content')
    <div class="container d-grid mt-5"
        style="grid-template-rows: repeat(4, 1fr); height: 100vh; gap: 1rem; text-align: center;">
        <div>
            <p class="h1">How to make money blogging:<br> the complete free guide</p>
        </div>
        <div>
            <p class="h4">Ready to share your ideas with the world? Start your blog →</p>
            <img src="{{ asset('public/image/abc7.webp') }}" class="mt-4" alt="..." style="height: 300px; width: 80%;">
        </div>
        <div>
            <p class="text-center mt-4">
                Making money blogging sounds like a dream. Not only do you get to work independently and skip the 9-to-5,
                but you can also blog from anywhere in the world about <br> the topics of your choice. While it involves
                hard work, even beginners can achieve this with the right strategy.
                You’ll need to create a blog, of course, in order to become <br>in a part of the blogosphere. After that,
                you’ll need to grow your audience. Whether you want a side hustle or a career, this comprehensive guide will
                walk you
                through <br> actionable steps on how to make a blog, build your readership and grow your blog. Then, you’ll
                learn about
                using the robust tools that can help you learn how to make <br> money blogging, turning your website traffic
                into
                money and potentially starting a business online. money blogging, turning your website traffic into
                money and potentially <br> starting a business online. money blogging, turning your website traffic into
                money and potentially starting a business online. money blogging.
            </p>
        </div>
    </div>
    <div class="container d-grid" style="grid-template-rows: repeat(4, 1fr); height: 100vh; gap: 1rem; text-align: center;">
        <div>
            <img src="{{ asset('public/image/abc5.webp') }}" class="mt-" alt="..."
                style="height: 300px; width: 80%;">
        </div>
        <div>
            <p class="text-center h5 mt-3">
                Ready to make money with a blog? Get started on your blog with Wix.
            </p>
        </div>
        <div class="container">
            <p class="h2">How much money can you make blogging?</p>
            <p>Before we dive into the steps to make money blogging, let’s talk about how much you can actually earn.


                How much money can you make when blogging as a beginner? Finance blog Millennial Money reports that after
                just two years of building traffic and subscribers to this type of a website, bloggers can make upwards of
                $100,000 annually. Within the first year, bloggers can make $500-$2,000 per month.


                Let’s look at a few examples from this study of successful bloggers:</p>
            </div>
        </div>
        <div class="container">
            <img src="{{ asset('public/image/abc5.webp') }}" class="mx-5 mb-5" alt="..."
                style="height: 300px; width: 80%;">
        </div>
@endsection
@section('css')
@endsection
@section('script')
@endsection --}}

@extends('layout.default')
@section('content')
    <div class="container d-grid mt-5"
        style="grid-template-rows: repeat(4, 1fr); height: 100vh; gap: 1rem; text-align: center;">
        <div>
            <p class="h1">How to make money blogging:<br> the complete free guide</p>
        </div>
        <div>
            <p class="h4">Ready to share your ideas with the world? Start your blog →</p>
            <img src="{{ asset('public/image/abc7.webp') }}" class="mt-4" alt="..." style="height: 400px; width: 100%;">
        </div>
        <div>
            <p class="text-center mt-4">
                Making money blogging sounds like a dream. Not only do you get to work independently and skip the 9-to-5,
                but you can also blog from anywhere in the world about <br> the topics of your choice. While it involves
                hard work, even beginners can achieve this with the right strategy.
                You’ll need to create a blog, of course, in order to become <br>in a part of the blogosphere. After that,
                you’ll need to grow your audience. Whether you want a side hustle or a career, this comprehensive guide will
                walk you
                through <br> actionable steps on how to make a blog, build your readership and grow your blog. Then, you’ll
                learn about
                using the robust tools that can help you learn how to make <br>blogging, turning your website traffic
                into
                money and potentially starting a business online. money blogging, turning your website traffic into
                money and potentially <br> starting a business online. money blogging, turning your website traffic into
                money and potentially starting a business online. money blogging.
            </p>
        </div>
    </div>
    <div class="container " style="height: 80vh;">
        <div>
            <img src="{{ asset('public/image/abc5.webp') }}" class="mt-5" alt="..."
                style="height: 300px; width: 100%;">
        </div>
        <div class="container">
            <p class="h5 mt-3">
                Ready to make money with a blog? Get started on your blog with Wix.
            </p>
            <p class="h2 mt-3">How much money can you make blogging?</p>
            <p>Before we dive into the steps to make money blogging, let’s talk about how much you can actually earn.
                How much money can you make when blogging as a beginner? Finance blog Millennial Money reports that after
                just two years of building traffic and subscribers to this type of a website, bloggers can make upwards of
                $100,000 annually. Within the first year, bloggers can make $500-$2,000 per month.
                Let’s look at a few examples from this study of successful bloggers:</p>

        </div>
    </div>
    <div class="container">
        <img src="{{ asset('public/image/abc10.webp') }}" class="" alt="..." style="height: 300px; width: 100%;">
        <p class="h5 mt-3">How to make money blogging in 11 steps</p>
        <p>Follow these 10 actionable steps to hone in on your craft and monetize your blogging efforts:</p>
        <p>1. Choose a profitable niche </p>
        <p>2. Scale your blog content  </p>
        <p>3. Build a reputation  </p>
        <p>4. Promote and grow  </p>
        <p>5. Go into affiliate marketing   </p>
        <p>6. Write sponsored content and reviews  </p>
        <p>7. Sell digital products (online courses, e-books and more)  </p>
        <p>8. Advertise within your blog  </p>
        <p>9. Offer paid subscriptions </p>
        <p>10. Provide consulting or freelancing services </p>
        <p>11. Sell physical products</p>

    </div>
@endsection
@section('css')
@endsection
@section('script')
@endsection
