@extends('layout.default')
@section('content')
    <div class="container">
        <p class="h1 mx-5 mt-3">Start Your Blog:</p>
        <div class="">
            <img src="{{ asset('public/upload/blog/' . $data['b_page1']->image) }}" class="d-block" alt="Template Preview"
                style="height: 400px; width: 100%;">
        </div>
    </div>
    <style>
        img:hover {
            transform: scale(1.05);
            transition: transform 0.3s ease;
        }
    </style>
    @php
        $image = ['public/image/abc2.jpg'];
    @endphp
    <div class="container">
        <p class="mx-5 mt-3">Starting a blog is an exciting way to share your passions, ideas, or expertise with the world.
            Whether you want to explore food, travel, technology, or personal stories, a blog can be a platform for
            creativity and connection. Begin by choosing a niche that resonates with you and aligns with your audience’s
            interests. Select a user-friendly platform like WordPress, create a unique domain name, and design an appealing
            layout. Focus on creating authentic, engaging content and maintaining a consistent posting schedule. Promote
            your blog through social media and optimize for search engines to grow your audience. With dedication, your blog
            can become a fulfilling endeavor.</p>
        <div class="d-flex mx-5 mt-4">
            <div class="col-md-4">
                <img src="{{ asset('public/image/abc13.webp') }}" alt="..." style="height: 400px; width: 100%;">
                <p class="text-center">Gaming Blog</p>
            </div>
            <div class="col-md-4">
                <img src="{{ asset('public/image/abc14.webp') }}" alt="..." style="height: 400px; width: 100%;">
                <p class="text-center">Minimalist and Sustainable Living Blog</p>
            </div>
            <div class="col-md-4">
                <img src="{{ asset('public/image/abc17.webp') }}" alt="..." style="height: 400px; width: 100%;">
                <p class="text-center">Travel Blog</p>
            </div>
        </div>
        <div class="d-flex mx-5 mt-3" style="margin: 0; padding: 0; gap: 0;">
            <div class="col-md-4 mx-2">
                <img src="{{ asset('public/image/abc21.webp') }}" alt="..." style="height: 400px; width: 100%;">
                <p class="text-center">Book and Literature Blog</p>
            </div>
            <div class="col-md-4 mx-2">
                <img src="{{ asset('public/image/laptop3.jpg') }}" alt="..." style="height: 400px; width: 100%;">
                <p class="text-center">Pet Blog</p>
            </div>
            <div class="col-md-4 mx-2">
                <img src="{{ asset('public/image/abc5.webp') }}" alt="..." style="height: 400px; width: 100%;">
                <p class="text-center">Entertainment Blog</p>
            </div>
        </div>
        <div class="d-flex mx-5 mt-3" style="margin: 0; padding: 0; gap: 0;">
            <div class="col-md-4 mx-2">
                <img src="{{ asset('public/image/abc3.jpeg') }}" alt="..." style="height: 400px; width: 100%;">
                <p class="text-center">Photography Blog</p>
            </div>
            <div class="col-md-4 mx-2">
                <img src="{{ asset('public/image/abc1.jpg') }}" alt="..." style="height: 400px; width: 100%;">
                <p class="text-center">Photography Blog</p>
            </div>
            <div class="col-md-4 mx-2">
                <img src="{{ asset('public/image/abc27.webp') }}" alt="..." style="height: 400px; width: 100%;">
                <p class="text-center">DIY and Crafts Blog</p>
            </div>
        </div>
        <div class="d-flex mx-5 mb-5 mt-3" style="margin: 0; padding: 0; gap: 0;">
            <div class="col-md-4 mx-2">
                <img src="{{ asset('public/image/abc34.webp') }}" alt="..." style="height: 400px; width: 100%;">
                <p class="text-center">Education Blog</p>
            </div>
            <div class="col-md-4 mx-2">
                <img src="{{ asset('public/image/abc36.webp') }}" alt="..." style="height: 400px; width: 100%;">
                <p class="text-center">Personal Finance Blog</p>

            </div>
            <div class="col-md-4 mx-2">
                <img src="{{ asset('public/image/abc7.webp') }}" alt="..." style="height: 400px; width: 100%;">
                <p class="text-center">Parenting and Family Blog</p>
            </div>
        </div>
    </div>
@endsection
@section('css')
@endsection
@section('script')
@endsection
