@extends('layout.default')

@section('content')
    <main id="main" class="site-main wpex-clr">
        <header
            class="page-header has-aside default-page-header wpex-relative wpex-mb-40 wpex-surface-2 wpex-py-20 wpex-border-t wpex-border-b wpex-border-solid wpex-border-surface-3 wpex-text-2 wpex-supports-mods">
            <div
                class="page-header-inner container wpex-md-flex wpex-md-flex-wrap wpex-md-items-center wpex-md-justify-between">
                <div class="page-header-content wpex-md-mr-15">
                    <h1 class="mt-1 page-header-title wpex-block wpex-m-0 wpex-text-2xl">
                        <span>Blog</span>
                    </h1>
                    <div class="page-subheading wpex-last-mb-0 wpex-text-md">
                        <p>Creating a blog website is one of the best ways to share your ideas, expertise, or passion with
                            the world. Whether you’re a seasoned blogger or just starting, having a well-structured blog
                            website can make all the difference. Modern blog templates offer a clean, user-friendly
                            interface that ensures readers can easily navigate through your content. These templates cater
                            to a variety of niches, including lifestyle, technology, food, travel, and fashion, making it
                            simple to customize a design that fits your unique brand.

                            A good blog website isn’t just about aesthetics—it’s about functionality. Responsive design is a
                            must, allowing your site to look and function flawlessly across all devices. Features like SEO
                            optimization, fast loading speeds, and social media integration help you reach a wider audience.
                            For example, a travel blog can benefit from galleries to showcase photos, while a tech blog
                            might emphasize categories and tags to organize in-depth reviews and tutorials.

                            Content is king, but presentation is equally important. The best blog templates often come with
                            customizable color schemes, typography options, and widgets that allow you to highlight popular
                            posts, categories, or recent updates. Additionally, advanced features like contact forms,
                            newsletter subscriptions, and comment sections encourage reader interaction and build a loyal
                            audience.

                            Blogging is not only a creative outlet but also a potential revenue stream. Many templates
                            support eCommerce integration, making it easy to sell products, offer paid memberships, or run
                            ads. With the right tools and strategy, your blog can evolve into a professional platform that
                            generates income.

                            Whether you’re sharing personal stories, industry insights, or creative projects, a blog website
                            built with modern tools ensures your voice reaches its intended audience in style. Take the
                            first step today and create a blog that stands out!</p>
                    </div>
                </div>
            </div>
        </header>
        <div id="content-wrap" class="container wpex-clr">
            <div class="row">
                @foreach ($data['code1'] as $code)
                    @if (!empty($code))
                        <div class="col-md-4 mb-4 mt-5">
                            <div class="wpex-card wpex-card-portfolio_2">
                                <div class="wpex-card-media">
                                    <div class="wpex-card-thumbnail wpex-relative ">
                                        <a href="{{ route('blog-page', ['id' => $code->id]) }}">

                                            <img src="{{ asset('public/upload/blog/' . $code->image) }}" class="img-fluid "
                                                alt="{{ $code->title }}"
                                                style=" height: 250px; width: 100%; object-fit: cover;">
                                        </a>
                                    </div>
                                </div>
                                <h5 class="wpex-card-title wpex-heading wpex-text-base mx-3">
                                    <a href="#" style="text-decoration: none;"
                                        class="text-dark">{{ $code->title }}</a>
                                </h5>
                                <div class="wpex-card-terms-list mx-3">
                                    <a href="#" style="text-decoration: none;" class="text-dark ">Blog</a> &middot;
                                    <a href="#" style="text-decoration: none;"
                                        class="text-dark ">{{ $code->description }}</a>
                                </div>
                            </div>
                        </div>
                    @endif
                @endforeach
            </div>
        </div>
    </main>
@endsection

{{-- @extends('layout.admin')
@section('content')
    <style>
        a {
            text-decoration: none;
            color: black;
        }

        .activated {
            color: black;
            border-bottom: 2px solid !important;
        }
    </style>
    <div class="col-md-12 text-center">
        
        <a href="{{ url('blog/list') }}" class="{{ request()->is('blog/list') ? 'activated' : '' }} "> View list</a>
        <a href="{{ url('blog/view') }}" class="{{ request()->is('blog/view') ? 'activated' : '' }} "> View blog</a>
        <a href="{{ route('blog-add') }}" class="mt-4 h4 btn btn-dark">+ Add Blog</a>
        @if (session('success'))
            <div class="alert alert-success mt-3">{{ session('success') }}</div>
        @endif
        <div class="container p-2">
            <div class="row">
                <div class="col">
                    <div class="table-responsive">
                        <table class="table table-secondary table-hover">
                            <thead>
                                <tr>
                                    <th>Title</th>
                                    <th>Description</th>
                                    <th>Image</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($blogs as $blog)
                                    <tr>
                                        <td>{{ $blog->title }}</td>
                                        <td>{{ $blog->description }}</td>
                                        <td>
                                            @if ($blog->image)
                                                <img src="{{ asset('public/upload/blog/' . $blog->image) }}"
                                                    style="width: 100px; height:50px;">
                                            @else
                                                <span>No Image</span>
                                            @endif
                                        </td>
                                        @php
                                            $bgColor = '';
                                            switch ($blog->status) {
                                                case 'active':
                                                    $bgColor = 'bg-success';
                                                    break;
                                                case 'inactive':
                                                    $bgColor = 'bg-danger';
                                                    break;
                                                case 'pending':
                                                    $bgColor = 'bg-warning';
                                                    break;

                                                default:
                                                    $bgColor = 'bg-success';
                                                    break;
                                            }
                                        @endphp
                                        <td><a href=""
                                                class="btn text-white {{ $bgColor }}">{{ $blog->status }}</a>
                                        </td>
                                        <td>
                                            <a href="{{ route('blog-edit', $blog->id) }}" class="btn btn-success"><i
                                                    class="bi bi-pencil-square"></i></a>

                                            <a href="{{ route('blog-delete', $blog->id) }}" class="btn btn-danger"
                                                onclick="return confirm('Are you sure?')"><i
                                                    class="bi bi-trash3-fill"></i></a>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection --}}

{{-- <a href="{{url('blog/page3/list')}}" class="{{request()->is('blog/page3/list') ? 'activated' : ''}} mx-5"> view blog</a> --}}
        {{-- <a href="{{ url('blog/viewblog') }}" class="{{ request()->is('blog/viewblog') ? 'activated' : '' }} mx-5"> view
            blog</a> --}}