@extends('layout.admin')
@section('content')
    <div class="col-md-12 text-center">
        <a href="{{ route('sblog-addvoucher') }}" class="mt-4 h4 btn btn-dark">+ Add Voucher</a>
        @if (session('success'))
            <div class="alert alert-success mt-3">{{ session('success') }}</div>
        @endif
        <div class="container p-2">
            <div class="row">
                <div class="col">
                    <div class="table-responsive">
                        <table class="table table-secondary table-hover">
                            <thead>
                                <tr>
                                    <th>Promotion</th>
                                    <th>Title</th>
                                    <th>Image</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($sblogs as $sblog)
                                    <tr>
                                        <td>{{ $sblog->promotion }}</td>
                                        <td>{{ $sblog->title }}</td>
                                        <td>
                                            @if ($sblog->image)
                                                <img src="{{ asset('public/upload/blog/' . $sblog->image) }}"
                                                    style="width: 200px; height:80px;">
                                            @else
                                                <span>No Image</span>
                                            @endif
                                        </td>
                                        @php
                                            $bgColor = '';
                                            switch ($sblog->status) {
                                                case 'active':
                                                    $bgColor = 'bg-success';
                                                    break;
                                                case 'inactive':
                                                    $bgColor = 'bg-danger';
                                                    break;
                                                case 'pending':
                                                    $bgColor = 'bg-warning';
                                                    break;

                                                default:
                                                    $bgColor = 'bg-success';
                                                    break;
                                            }
                                        @endphp
                                        <td><a href=""
                                                class="btn text-white {{ $bgColor }}">{{ $sblog->status }}</a>
                                        </td>
                                        <td>
                                            <a href="{{ route('sblog-edit', ['id' => $sblog->id]) }}"
                                                class="btn btn-success"><i class="bi bi-pencil-square"></i></a>

                                            <a href="{{ route('sblog-delete', ['id' => $sblog->id]) }}"
                                                class="btn btn-danger" onclick="return confirm('Are you sure?')"><i
                                                    class="bi bi-trash3-fill"></i></a>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
