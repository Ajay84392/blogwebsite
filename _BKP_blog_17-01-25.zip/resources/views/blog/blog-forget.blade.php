<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
@yield('css')
</head>
<div>
    <img src="{{ asset('public/image/abc6.webp') }}" class="d-block" alt="..." style="height: 800px; width: 100%;">
</div>
<div class="card-img-overlay mt-5">
    <div class="card bg-white center mt-5" style="height:fit-content; width: 30rem;margin-left:auto;margin-right:auto;">
        <div class="card-body">
            <form action="{{ route('blog-forget-email') }}" method="post" class="needs-validation" autocomplete="new-password"
                novalidate>
                @csrf
                    <div class="d-flex justify-content-center ">
                        <img src="{{ asset('public/image/abc4.jpg') }}" class="d-block" alt="..."
                        style="height:100px;width:10rem;">
                    </div>
                <div class="">
                    <i class="bi fs-5 bi-envelope-fill"></i>
                    <label for="exampleFormControlInput2" class="mt-2 h6  form-label">Email </label>
                    <input type="email" class="form-control" id="email" name="email" autocomplete="new-password"
                        placeholder="name@example.com">
                    <div class="invalid-feedback">
                        * Required Field.
                    </div>
                </div>
                <div class="mb-3 mt-2">
                    <i class="bi fs-5 bi-lock-fill"></i>
                    <label for="exampleFormControlTextarea1" class="mt-3 h6 form-label">New Password</label>
                    <input type="password" class="form-control" id="new-password" name="new-password"
                        autocomplete="new-password" rows="3">
                </div>
                <div class="mb-3 mt-2">
                    <i class="bi fs-5 bi-lock-fill"></i>
                    <label for="exampleFormControlTextarea1" class="mt-3 h6 form-label">Confirm Password</label>
                    <input type="password" class="form-control" id="confirm-password" name="confirm-password"
                        autocomplete="new-password" rows="3">
                </div>
                <div class="text-center">
                    <button type="submit" class="mt-3 bg-dark form-control btn btn-primary">Forget Password</button>
                </div>
            </form>
        </div>
    </div>
</div>
