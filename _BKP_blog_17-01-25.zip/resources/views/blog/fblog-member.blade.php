@extends('layout.admin')
@section('content')
    <div class="col-md-12 text-center">
        <a href="{{ route('fblog-adduser') }}" class="mt-4 h4 btn btn-dark">+ Add User</a>
        @if (session('success'))
            <div class="alert alert-success mt-3">{{ session('success') }}</div>
        @endif
        <div class="container p-2">
            <div class="row">
                <div class="col">
                    <div class="table-responsive">
                        <table class="table table-secondary table-hover">
                            <thead>
                                <tr>
                                    <th>User Group</th>
                                    <th>Agency</th>
                                    <th>First Name</th>
                                    <th>Last Name</th>
                                    <th>Email</th>
                                    <th>Contact</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($fblogs as $fblog)
                                    <tr>
                                        <td class="text-truncate" style="max-width: 150px;">{{ $fblog->user_group }}</td>
                                        <td>{{ $fblog->agency }}</td>
                                        <td>{{ $fblog->first_name }}</td>
                                        <td>{{ $fblog->last_name }}</td>
                                        <td>{{ $fblog->email }}</td>
                                        <td>{{ $fblog->contact }}</td>
                                        @php
                                            $bgColor = '';
                                            switch ($fblog->status) {
                                                case 'active':
                                                    $bgColor = 'bg-success';
                                                    break;
                                                case 'inactive':
                                                    $bgColor = 'bg-danger';
                                                    break;
                                                case 'pending':
                                                    $bgColor = 'bg-warning';
                                                    break;

                                                default:
                                                    $bgColor = 'bg-success';
                                                    break;
                                            }
                                        @endphp
                                        <td><a href=""
                                                class="btn text-white {{ $bgColor }}">{{ $fblog->status }}</a>
                                        </td>
                                        <td>
                                            <a href="{{ route('fblog-edit', ['id' => $fblog->id]) }}"
                                                class="btn btn-success"><i class="bi bi-pencil-square"></i></a>

                                            <a href="{{ route('fblog-delete', ['id' => $fblog->id]) }}"
                                                class="btn btn-danger" onclick="return confirm('Are you sure?')"><i
                                                    class="bi bi-trash3-fill"></i></a>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
