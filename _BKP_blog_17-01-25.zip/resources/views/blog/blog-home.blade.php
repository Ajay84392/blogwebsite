{{-- @extends('layout.admin')
@section('content')
    <div class="mt-4">
        <p class="h4 mx-3">Dashboard</p>
        <div class="d-flex mt-4 mx-3">
            <div class="card bg-dark" style="width: 16rem; height: 130px;">
                <div class="d-flex align-items-center">
                    <i class="bi fs-4 mt-2 mx-3 bi-table text-white"></i>
                    <span class="text-success mt-2" style="font-size: 1.5rem;">{{ $data['count_status'] }}</span>
                </div>
                <div class="card-body">
                    <h5 class="card-title text-white">TOTAL BLOG</h5>
                    <div class="progress" role="progressbar" aria-label="success example" aria-valuenow="50"
                        aria-valuemin="0" aria-valuemax="100">
                        <div class="progress-bar bg-success" style="width: 50%"></div>
                    </div>
                </div>
            </div>
            <div class="card bg-dark mx-4" style="width: 16rem; height: 130px;">                                                                                                      
                <div class="d-flex align-items-center">
                    <i class="bi fs-4 mt-2 mx-3 bi-people text-white"></i>
                    <span class="text-warning mt-2" style="font-size: 1.5rem;">{{ $data['blogmember'] }}</span>
                </div>
                <div class="card-body">
                    <h5 class="card-title text-white">TOTAL MEMBER</h5>
                    <div class="progress" role="progressbar" aria-label="Warning example" aria-valuenow="75"
                        aria-valuemin="0" aria-valuemax="100">
                        <div class="progress-bar bg-warning" style="width: 35%"></div>
                    </div>
                </div>
            </div>
            <div class="card bg-dark mx-1" style="width: 16rem; height: 130px;">
                <div class="d-flex align-items-center">
                    <i class="bi fs-4 mt-2 mx-3 bi-card-list text-white"></i>
                    <span class="text-primary mt-2" style="font-size: 1.5rem;">{{ $data['blogvoucher'] }}</span>
                </div>
                <div class="card-body">
                    <h5 class="card-title text-white">TOTAL VOUCHER</h5>
                    <div class="progress" role="progressbar" aria-label="primary example" aria-valuenow="100"
                        aria-valuemin="0" aria-valuemax="100">
                        <div class="progress-bar bg-primary" style="width: 90%"></div>
                    </div>
                </div>
            </div>
            <div class="card bg-dark mx-4" style="width: 16rem; height: 130px;">
                <div class="d-flex align-items-center">
                    <i class="bi fs-4 mt-3 mx-3 bi-wifi text-white"></i>
                    <span class="text-danger mt-2" style="font-size: 1.5rem;">{{ $data['blogvoucher'] }}</span>
                </div>
                <div class="card-body">
                    <h5 class="card-title text-white">TOTAL RESERVATIONS</h5>
                    <div class="progress" role="progressbar" aria-label="primary example" aria-valuenow="100"
                        aria-valuemin="0" aria-valuemax="100">
                        <div class="progress-bar bg-danger" style="width: 20%"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <link rel=
    "https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css" type="text/css" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.3/modernizr.min.js" type="text/javascript"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.2.2/Chart.min.js"></script>
    
    <div class="container">
        <div class="mx- mt-4" style="width: 50%; height: 400px;">
            <canvas id="myChart"></canvas>
        </div>

        <body>
            <script>
                const ctx = document.getElementById("myChart").getContext("2d");
                const myChart = new Chart(ctx, {
                    type: "line",
                    data: {
                        labels: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"],
                        datasets: [{
                                label: "Total Blog",
                                data: [2, 9, 3, 17, 6, 3, 7],
                                backgroundColor: "rgba(0)",
                                fill: true,
                            },
                            {
                                label: "Total Members",
                                data: [2, 7, 9, 15, 8, 10, 12],
                                backgroundColor: "rgba(0)",
                                fill: true,
                            },
                            {
                                label: "Total Vouchers",
                                data: [1, 4, 5, 2, 10, 3, 5],
                                backgroundColor: "rgba(0)",
                                fill: true,
                            },
                        ],
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        scales: {
                            y: {
                                beginAtZero: true,
                            },
                        },
                    },
                });
            </script>
        </body>
    </div>
@endsection --}}

@extends('layout.admin')
@section('content')
    {{-- <div class="mt-4">
        <p class="h4 mx-3">Dashboard</p>
        <div class="d-flex mt-4 mx-3">
            <div class="card bg-dark" style="width: 16rem; height: 130px;">
                <div class="d-flex align-items-center">
                    <i class="bi fs-4 mt-2 mx-3 bi-table text-white"></i>
                    <span class="text-success mt-2" style="font-size: 1.5rem;">{{ $data['count_status'] }}</span>
                </div>
                <div class="card-body">
                    <h5 class="card-title text-white">TOTAL BLOG</h5>
                    <div class="progress" role="progressbar" aria-label="success example" aria-valuenow="50"
                        aria-valuemin="0" aria-valuemax="100">
                        <div class="progress-bar bg-success" style="width: 50%"></div>
                    </div>
                </div>
            </div>
            <div class="card bg-dark mx-4" style="width: 16rem; height: 130px;">
                <div class="d-flex align-items-center">
                    <i class="bi fs-4 mt-2 mx-3 bi-people text-white"></i>
                    <span class="text-warning mt-2" style="font-size: 1.5rem;">{{ $data['blogmember'] }}</span>
                </div>
                <div class="card-body">
                    <h5 class="card-title text-white">TOTAL MEMBER</h5>
                    <div class="progress" role="progressbar" aria-label="Warning example" aria-valuenow="75"
                        aria-valuemin="0" aria-valuemax="100">
                        <div class="progress-bar bg-warning" style="width: 35%"></div>
                    </div>
                </div>
            </div>
            <div class="card bg-dark mx-1" style="width: 16rem; height: 130px;">
                <div class="d-flex align-items-center">
                    <i class="bi fs-4 mt-2 mx-3 bi-card-list text-white"></i>
                    <span class="text-primary mt-2" style="font-size: 1.5rem;">{{ $data['blogvoucher'] }}</span>
                </div>
                <div class="card-body">
                    <h5 class="card-title text-white">TOTAL VOUCHER</h5>
                    <div class="progress" role="progressbar" aria-label="primary example" aria-valuenow="100"
                        aria-valuemin="0" aria-valuemax="100">
                        <div class="progress-bar bg-primary" style="width: 90%"></div>
                    </div>
                </div>
            </div>
            <div class="card bg-dark mx-4" style="width: 16rem; height: 130px;">
                <div class="d-flex align-items-center">
                    <i class="bi fs-4 mt-3 mx-3 bi-wifi text-white"></i>
                    <span class="text-danger mt-2" style="font-size: 1.5rem;">{{ $data['blogvoucher'] }}</span>
                </div>
                <div class="card-body">
                    <h5 class="card-title text-white">TOTAL RESERVATIONS</h5>
                    <div class="progress" role="progressbar" aria-label="primary example" aria-valuenow="100"
                        aria-valuemin="0" aria-valuemax="100">
                        <div class="progress-bar bg-danger" style="width: 20%"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <link rel=
    "https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css" type="text/css" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.3/modernizr.min.js" type="text/javascript"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.2.2/Chart.min.js"></script>
    <div class="container">
        <div class="mx- mt-4" style="width: 50%; height: 400px;">
            <canvas id="myChart"></canvas>
        </div>
        <body>
            <script>
                const ctx = document.getElementById("myChart").getContext("2d");
                const myChart = new Chart(ctx, {
                    type: "line",
                    data: {
                        labels: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"],
                        datasets: [{
                                label: "Total Blog",
                                data: [2, 9, 3, 17, 6, 3, 7],
                                backgroundColor: "rgba(0)",
                                fill: true,
                            },
                            {
                                label: "Total Members",
                                data: [2, 7, 9, 15, 8, 10, 12],
                                backgroundColor: "rgba(0)",
                                fill: true,
                            },
                            {
                                label: "Total Vouchers",
                                data: [1, 4, 5, 2, 10, 3, 5],
                                backgroundColor: "rgba(0)",
                                fill: true,
                            },
                        ],
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        scales: {
                            y: {
                                beginAtZero: true,
                            },
                        },
                    },
                });
            </script>
        </body>
    </div> --}}
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Symbols+Rounded" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    
    <div class="container mt-5">
        <div class="row">
            <div class="col-lg-4 col-md-6 mt-4 mb-4">
                <div class="card">
                    <div class="card-body">
                        <h6 class="mb-0">Website Views</h6>
                        <p class="text-sm">Last Campaign Performance</p>
                        <div class="pe-2">
                            <div class="chart">
                                <canvas id="chart-bars" class="chart-canvas" height="170"></canvas>
                            </div>
                        </div>
                        <hr class="dark horizontal">
                        <div class="d-flex">
                            <i class="material-symbols-rounded text-sm my-auto me-1">schedule</i>
                            <p class="mb-0 text-sm">campaign sent 2 days ago</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        const ctx = document.getElementById('chart-bars').getContext('2d');
        const chart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'],
                datasets: [{
                    label: 'Views',
                    data: [12, 19, 3, 5, 2],
                    backgroundColor: 'rgba(75, 192, 192, 0.2)',
                    borderColor: 'rgba(75, 192, 192, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    </script>
@endsection
