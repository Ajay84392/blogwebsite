@extends('layout.default')
@section('content')
    <style>
        img:hover {
            transform: scale(1.05);
            transition: transform 0.3s ease;
        }
    </style>
    <main id="main" class="site-main wpex-clr">
        <div id="content-wrap" class="container wpex-clr">
            <div class="d-flex mt-3">
                <p class="h3 mt-2 text-secondary mx-2">Result found for:</p>
                <p class="h3 mt-2">'Fashion Blog'</p>
            </div>
            <div class="d-flex justify-content-between align-items-center mt-4">
                <p class="h5 mx-2">Want Help Picking a Template?</p>
                <div class="d-flex align-items-center">
                    <p class="h5 mb-0">Sorted By:</p>
                    <div class="dropdown">
                        <button class="btn dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Recommended
                        </button>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="#">Recommended</a></li>
                            <li><a class="dropdown-item" href="#">Newest</a></li>
                            <li><a class="dropdown-item" href="#">Most Popular</a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="row">
                @foreach ($data['code2'] as $code)
                    @if (!empty($code))
                        <div class="col-md-3 mb-4 mt-5">
                            <div class="wpex-card wpex-card-portfolio_2">
                                <div class="wpex-card-media">
                                    <div class="wpex-card-thumbnail wpex-relative ">
                                        <a href="{{ route('blog-page4', ['id' => $code->id]) }}">
                                            <img src="{{ asset('public/upload/blog/' . $code->image) }}" class="img-fluid "
                                                alt="{{ $code->title }}"
                                                style=" height: 250px; width: 100%; object-fit: cover;">
                                        </a>
                                    </div>
                                </div>
                                <h5 class="wpex-card-title wpex-heading wpex-text-base mx-3">
                                    <a href="#" style="text-decoration: none;"
                                        class="text-dark">{{ $code->title }}</a>
                                </h5>
                                <div class="wpex-card-terms-list mx-3">
                                    <a href="#" style="text-decoration: none;"
                                        class="text-dark ">{{ $code->description }}</a>
                                </div>
                            </div>
                        </div>
                    @endif
                @endforeach
            </div>
        </div>
    </main>
@endsection

{{-- @extends('layout.default')
@section('content')
    <style>
        img:hover {
            transform: scale(1.05);
            transition: transform 0.3s ease;
        }
    </style>
    <main id="main" class="site-main wpex-clr">
        <div id="content-wrap" class="container wpex-clr">
            <!-- Display Search Results -->
            <div class="d-flex mt-3">
                <p class="h3 mt-2 text-secondary mx-2">Result found for:</p>
                <p class="h3 mt-2">'Fashion Blog'</p>
            </div>
            
            <!-- Sorting Dropdown -->
            <div class="d-flex">
                <p class="h5 mx-1 mt-4">Want Help Picking a Template?</p>
                <p class="h5 mt-4" style="margin:auto;">Sorted By:</p>
                <div class="dropdown">
                    <button class="btn dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                        {{ request('sort') ?? 'Recommended' }}
                    </button>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="{{ route('your-route-name', ['sort' => 'recommended']) }}">Recommended</a></li>
                        <li><a class="dropdown-item" href="{{ route('your-route-name', ['sort' => 'newest']) }}">Newest</a></li>
                        <li><a class="dropdown-item" href="{{ route('your-route-name', ['sort' => 'popular']) }}">Most Popular</a></li>
                    </ul>
                </div>
            </div>
            
            <!-- Display Blogs -->
            <div class="row">
                @foreach ($data['code2'] as $code)
                    @if (!empty($code))
                        <div class="col-md-3 mb-4 mt-5">
                            <div class="wpex-card wpex-card-portfolio_2">
                                <div class="wpex-card-media">
                                    <div class="wpex-card-thumbnail wpex-relative">
                                        <a href="{{ route('blog-page4', ['id' => $code->id]) }}">
                                            <img src="{{ asset('public/upload/blog/' . $code->image) }}" class="img-fluid"
                                                alt="{{ $code->title }}"
                                                style="height: 250px; width: 100%; object-fit: cover;">
                                        </a>
                                    </div>
                                </div>
                                <h5 class="wpex-card-title wpex-heading wpex-text-base mx-3">
                                    <a href="#" style="text-decoration: none;" class="text-dark">{{ $code->title }}</a>
                                </h5>
                                <div class="wpex-card-terms-list mx-3">
                                    <a href="#" style="text-decoration: none;" class="text-dark">{{ $code->description }}</a>
                                </div>
                            </div>
                        </div>
                    @endif
                @endforeach
            </div>
        </div>
    </main>
@endsection --}}
