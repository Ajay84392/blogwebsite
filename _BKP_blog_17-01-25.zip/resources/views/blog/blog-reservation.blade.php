@extends('layout.admin')
@section('content')
    <p CLASS="h5 mx-4 mt-4">USERS</p>
    <div class="col-md-6 mx-4 ">

        <input class="form-control bg-light form-control-sm fs-5 mt-3 " type="search" placeholder="User Name"
            aria-label="Search" style="height:32px;">
        <span class="input-group-text bg-purple-light py-0">

        </span>
    </div>
    <div class="col-md-12 text-end">
        @if (session('success'))
            <div class="alert alert-success mt-3">{{ session('success') }}</div>
        @endif
        <a href="{{ route('fblog-adduser') }}" class="mx-4 h4 btn btn-dark">+ Add User</a>

        <div class="container mt-4">
            <div class="row">
                <div class="col">
                    <div class="table-responsive">
                        <table class="table table-secondary table-hover">
                            <thead>
                                <tr>
                                    <th>User Group</th>
                                    <th>Agency</th>
                                    <th>First Name</th>
                                    <th>Last Name</th>
                                    <th>Email</th>
                                    <th>Contact</th>
                                    <th>Status</th>
                                    <th>Action</th>

                                </tr>
                            </thead>
                            <tbody>


                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
