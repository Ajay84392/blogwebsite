@extends('layout.admin')
@section('content')
    <div class="container ">
        <h2 class="mt-4 ">Edit Blog</h2>
        <form action="{{ route('blog-edit', $blog->id) }}" method="POST" enctype="multipart/form-data">
            @csrf
            <!-- Title Field -->
            <div class="form-group ">
                <label for="title">Title</label>
                <input type="text" name="title" class="mt-2 form-control" value="{{ $blog->title }}"
                    placeholder="Enter Blog Title" required>
            </div>

            <!-- Description Field -->
            <div class="form-group mt-3">
                <label for="description">Description</label>
                <textarea name="description" class="mt-2 form-control" rows="5" placeholder="Enter Blog Description" required>{{ $blog->description }}</textarea>
            </div>

            <div class="form-group mt-5 h6 col-md-6">
                <label for="status">Status</label>
                <select name="status" class="form-control bg-primary-subtle" required>

                    <option value="Active" {{ $blog->status == 'active' ? 'selected' : '' }}>Active</option>
                    <option value="Inactive" {{ $blog->status == 'inactive' ? 'selected' : '' }}>Inactive</option>
                    <option value="pending" {{ $blog->status == 'pending' ? 'selected' : '' }}>Pending</option>
                </select>
            </div>

            <!-- Existing Image -->
            @if ($blog->image)
                <div class="form-group mt-3">
                    <label>Current Image</label><br>
                    <img src="{{ asset('public/upload/blog/' . $blog->image) }}" style="width: 150px; height: auto;"
                        alt="">
                </div>
            @endif

            <!-- Image Upload Field -->
            <div class="form-group mt-3">
                <label for="image">Upload New Image (optional)</label>
                <input type="file" name="image" class="form-control">
            </div>

            <!-- Submit Button -->
            <button type="submit" class="mt-3 btn btn-primary">Update Blog</button>
        </form>
    </div>
@endsection
