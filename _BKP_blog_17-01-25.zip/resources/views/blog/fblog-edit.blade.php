{{-- @extends('layout.admin')
@section('content')
    <div class="container">
        <p class="h5 mt-4">USER ADD</p>
        <form action="{{ route('fblog-edit') }}" method="POST" >
            @csrf
            <!-- Title Field -->
            <div class="form-group h6 mt-3 col-md-6 ">
                <label for="title">User Group</label>
                <input type="text" name="user_group" class="form-control bg-primary-subtle" placeholder="Enter Blog Title"
                    required>
            </div>
            <!-- Description Field -->
            <div class="form-group mt-3 h6 col-md-6" style="width: 37rem; height: 200px;">
                <label for="description">Agency</label>
                <textarea name="agency" class="form-control bg-primary-subtle" rows="7" placeholder="Enter Blog Description"
                    required></textarea>
            </div>
            <div class="form-group h6 mt-3 col-md-6 ">
                <label for="title">First Name</label>
                <input type="text" name="first_name" class="form-control bg-primary-subtle" placeholder="Enter Blog Title"
                    required>
            </div>
            <div class="form-group h6 mt-3 col-md-6 ">
                <label for="title">Last Name</label>
                <input type="text" name="last_name" class="form-control bg-primary-subtle" placeholder="Enter Blog Title"
                    required>
            </div>
            <div class="form-group h6 mt-3 col-md-6 ">
                <label for="title">Email</label>
                <input type="text" name="email" class="form-control bg-primary-subtle" placeholder="Enter Blog Title"
                    required>
            </div>
            <div class="form-group h6 mt-3 col-md-6 ">
                <label for="title">Contact</label>
                <input type="text" name="contact" class="form-control bg-primary-subtle" placeholder="Enter Blog Title"
                    required>
            </div>
            <div class="form-group mt-3 h6 col-md-6">
                <label for="status">Status</label>
                <select name="status" class="form-control bg-primary-subtle" required>
                    <option value="Active">Active</option>
                    <option value="Inactive">Inactive</option>
                </select>
            </div>
            <!-- Submit Button -->
            <button type="submit" class="btn btn-primary mt-3 mb-3">Update User</button>
        </form>
    </div>
@endsection
@section('css')
@endsection
@section('script')
@endsection --}}

@extends('layout.admin')
@section('content')
    <div class="container">
        <p class="h5 mt-4">Edit User</p>
        <form action="{{ route('fblog-edit', ['id' => $fblog->id]) }}" method="POST">
            @csrf
            {{-- @method('POST') <!-- If you want to simulate PUT, use @method('PUT') --> --}}

            <!-- User Group -->
            <div class="form-group h6 mt-3 col-md-6">
                <label for="user_group">User Group</label>
                <input type="text" name="user_group" class="form-control bg-primary-subtle" 
                       value="{{ old('user_group', $fblog->user_group) }}" required>
            </div>

            <!-- Agency -->
            <div class="form-group mt-3 h6 col-md-6">
                <label for="agency">Agency</label>
                <textarea name="agency" class="form-control bg-primary-subtle" rows="3" required>{{ old('agency', $fblog->agency) }}</textarea>
            </div>

            <!-- First Name -->
            <div class="form-group h6 mt-3 col-md-6">
                <label for="first_name">First Name</label>
                <input type="text" name="first_name" class="form-control bg-primary-subtle" 
                       value="{{ old('first_name', $fblog->first_name) }}" required>
            </div>

            <!-- Last Name -->
            <div class="form-group h6 mt-3 col-md-6">
                <label for="last_name">Last Name</label>
                <input type="text" name="last_name" class="form-control bg-primary-subtle" 
                       value="{{ old('last_name', $fblog->last_name) }}" required>
            </div>

            <!-- Email -->
            <div class="form-group h6 mt-3 col-md-6">
                <label for="email">Email</label>
                <input type="email" name="email" class="form-control bg-primary-subtle" 
                       value="{{ old('email', $fblog->email) }}" required>
            </div>

            <!-- Contact -->
            <div class="form-group h6 mt-3 col-md-6">
                <label for="contact">Contact</label>
                <input type="text" name="contact" class="form-control bg-primary-subtle" 
                       value="{{ old('contact', $fblog->contact) }}" required>
            </div>

            {{-- <!-- Status -->
            <div class="form-group mt-3 h6 col-md-6">
                <label for="status">Status</label>
                <select name="status" class="form-control bg-primary-subtle" required>
                    <option value="Active" {{ old('status', $fblog->status) === 'Active' ? 'selected' : '' }}>Active</option>
                    <option value="Inactive" {{ old('status', $fblog->status) === 'Inactive' ? 'selected' : '' }}>Inactive</option>
                    <option value="Pending" {{ old('status', $fblog->status) === 'Pending' ? 'selected' : '' }}>Pending</option>

                </select>
            </div> --}}

            <div class="form-group mt-5 h6 col-md-6">
                <label for="status">Status</label>
                <select name="status" class="form-control bg-primary-subtle" required>
                    <option value="Active">Active</option>
                    <option value="Inactive">Inactive</option>
                    <option value="pending">Pending</option>
                </select>
            </div>
            
            <!-- Submit Button -->
            <button type="submit" class="btn btn-primary mt-3 mb-3">Update User</button>
        </form>
    </div>
@endsection
