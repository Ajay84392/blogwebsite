@extends('layout.admin')
@section('content')
    <div class="container">
        <p class="h5 mt-4">BLOG ADD</p>
        <form action="{{ route('blog-add') }}" method="POST" enctype="multipart/form-data">
            @csrf
            <!-- Title Field -->
            <div class="form-group h6 mt-3 col-md-6 ">
                <label for="title">Title</label>
                <input type="text" name="title" class="form-control bg-primary-subtle" placeholder="Enter Title" required>
            </div>

            <div class="form-group mt-3 h6 col-md-6" style="width: 37rem; height: 200px;">
                <label for="description">Description</label>
                <textarea name="description" class="form-control bg-primary-subtle" rows="8" placeholder="Enter Description"
                    required></textarea>
            </div>

            <div class="form-group mt-5 h6 col-md-6">
                <label for="status">Status</label>
                <select name="status" class="form-control bg-primary-subtle" required>
                    <option value="Active">Active</option>
                    <option value="Inactive">Inactive</option>
                    <option value="pending">Pending</option>
                </select>
            </div>
            <div class="form-group h6 mt-3 col-md-6">
                <label for="type">Type</label>
                <select name="type" class="form-control bg-primary-subtle" required>
                    <option name="redirect_to" value="viewblog">View Blog</option>
                    <option name="redirect_to" value="viewlist">View List</option>
                </select>
            </div>
            <div class="form-group mt-3 h6 col-md-6">
                <label for="image">Upload Image</label>
                <input type="file" name="image" class="form-control">
            </div>
            <button type="submit" class="btn btn-primary mt-3">Add Blog</button>
        </form>
    </div>
@endsection
@section('css')
@endsection
@section('script')
@endsection
