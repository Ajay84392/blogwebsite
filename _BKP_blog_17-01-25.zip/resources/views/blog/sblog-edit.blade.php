{{-- @extends('layout.admin')
@section('content')
    <div class="container ">
        <h2 class="mt-4 ">Edit Blog</h2>
        <form action="{{ route('blog-edit', $blog->id) }}" method="POST" enctype="multipart/form-data">
            @csrf

            <!-- Title Field -->
            <div class="form-group ">
                <label for="title">Title</label>
                <input type="text" name="title" class="mt-2 form-control" value="{{ $blog->title }}" placeholder="Enter Blog Title" required>
            </div>

            <!-- Description Field -->
            <div class="form-group mt-3">
                <label for="description">Description</label>
                <textarea name="description" class="mt-2 form-control" rows="5" placeholder="Enter Blog Description" required>{{ $blog->description }}</textarea>
            </div>

            <!-- Existing Image -->
            @if ($blog->image)
                <div class="form-group mt-3">
                    <label>Current Image</label><br>
                    <img src="{{ asset('public/upload/blog/' . $blog->image) }}" style="width: 150px; height: auto;">
                </div>
            @endif

            <!-- Image Upload Field -->
            <div class="form-group mt-3">
                <label for="image">Upload New Image (optional)</label>
                <input type="file" name="image" class="form-control">
            </div>

            <!-- Submit Button -->
            <button type="submit" class="mt-3 btn btn-primary">Update Blog</button>
        </form>
    </div>
@endsection --}}

@extends('layout.admin')
@section('content')
    <div class="container ">
        <h2 class="mt-4 ">Edit Voucher</h2>
        <form action="{{ route('sblog-edit', $sblog->id) }}" method="POST" enctype="multipart/form-data">
            @csrf

            <!-- Title Field -->
            <div class="form-group ">
                <label for="promotion">promotion</label>
                <input type="text" name="promotion" class="mt-2 form-control" value="{{ $sblog->promotion }}"
                    placeholder="Enter sBlog promotion" required>
            </div>

            <!-- Description Field -->
            <div class="form-group mt-3">
                <label for="title">title</label>
                <textarea name="title" class="mt-2 form-control" rows="5" placeholder="Enter sBlog title" required>{{ $sblog->title }}</textarea>
            </div>

            <!-- Existing Image -->
            @if ($sblog->image)
                <div class="form-group mt-3">
                    <label>Current Image</label><br>
                    <img src="{{ asset('public/upload/blog/' . $sblog->image) }}" style="width: 150px; height: auto;">
                </div>
            @endif

            <!-- Image Upload Field -->
            <div class="form-group mt-3">
                <label for="image">Upload New Image (optional)</label>
                <input type="file" name="image" class="form-control">
            </div>

            <div class="form-group mt-5 h6 col-md-6">
                <label for="status">Status</label>
                <select name="status" class="form-control bg-primary-subtle" required>
                    <option value="Active">Active</option>
                    <option value="Inactive">Inactive</option>
                    <option value="pending">Pending</option>
                </select>
            </div>

            <!-- Submit Button -->
            <button type="submit" class="mt-3 btn btn-primary">Update Voucher</button>
        </form>
    </div>
@endsection
