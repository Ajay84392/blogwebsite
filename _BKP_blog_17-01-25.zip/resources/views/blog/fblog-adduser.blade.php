@extends('layout.admin')
@section('content')
    <div class="container">
        <p class="h5 mt-4">USER ADD</p>
        <form action="{{ route('fblog-adduser') }}" method="POST" >
            @csrf
            <!-- Title Field -->
            <div class="form-group h6 mt-3 col-md-6 ">
                <label for="title">User Group</label>
                <input type="text" name="user_group" class="form-control bg-primary-subtle" placeholder="Enter user group"
                    required>
            </div>
            <!-- Description Field -->
            <div class="form-group mt-3 h6 col-md-6" style="width: 37rem; height: 200px;">
                <label for="description">Agency</label>
                <textarea name="agency" class="form-control bg-primary-subtle" rows="7" placeholder="Enter agency"
                    required></textarea>
            </div>
            <div class="form-group h6 mt-3 col-md-6 ">
                <label for="title">First Name</label>
                <input type="text" name="first_name" class="form-control bg-primary-subtle" placeholder="Enter first name"
                    required>
            </div>
            <div class="form-group h6 mt-3 col-md-6 ">
                <label for="title">Last Name</label>
                <input type="text" name="last_name" class="form-control bg-primary-subtle" placeholder="Enter last name"
                    required>
            </div>
            <div class="form-group h6 mt-3 col-md-6 ">
                <label for="title">Email</label>
                <input type="text" name="email" class="form-control bg-primary-subtle" placeholder="Enter email"
                    required>
            </div>
            <div class="form-group h6 mt-3 col-md-6 ">
                <label for="title">Contact</label>
                <input type="text" name="contact" class="form-control bg-primary-subtle" placeholder="Enter contact"
                    required>
            </div>
            <div class="form-group mt-3 h6 col-md-6">
                <label for="status">Status</label>
                <select name="status" class="form-control bg-primary-subtle" required>
                    <option value="Active">Active</option>
                    <option value="Inactive">Inactive</option>
                    <option value="Pending">Pending</option>
                </select>
            </div>
            <!-- Submit Button -->
            <button type="submit" class="btn btn-primary mt-3 mb-3">Add User</button>
        </form>
    </div>
@endsection
@section('css')
@endsection
@section('script')
@endsection
