@extends('layout.admin')
@section('content')
    <div class="container">
        <p class="h5 mt-4">ADD VOUCHER</p>
        <form action="{{ route('sblog-addvoucher') }}" method="POST" enctype="multipart/form-data">
            @csrf
            <!-- Title Field -->
            <div class="form-group h6 mt-3 col-md-6 ">
                <label for="promotion">Promotion</label>
                <input type="text" name="promotion" class="form-control bg-primary-subtle" placeholder="Enter promotion"
                    required>
            </div>

            <!-- Description Field -->
            <div class="form-group mt-3 h6 col-md-6" style="width: 37rem; height: 200px;">
                <label for="title">Title</label>
                <textarea name="title" class="form-control bg-primary-subtle" rows="7" placeholder="Enter title"
                    required></textarea>
            </div>

            <!-- Image Upload Field -->
            <div class="form-group mt-3 h6 col-md-6">
                <label for="upload image">Upload Image</label>
                <input type="file" name="image" class="form-control" placeholder="chose your image file"
                required> 
            </div>

            <div class="form-group mt-5 h6 col-md-6">
                <label for="status">Status</label>
                <select name="status" class="form-control bg-primary-subtle" required>
                    <option value="active">Active</option>
                    <option value="inactive">Inactive</option>
                    <option value="pending">Pending</option>
                </select>
            </div>

            <!-- Submit Button -->
            <button type="submit" class="btn btn-primary mt-3">Add Voucher</button>
        </form>
    </div>
@endsection
@section('css')
@endsection
@section('script')
@endsection
