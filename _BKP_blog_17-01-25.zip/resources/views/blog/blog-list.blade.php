@extends('layout.admin')
@section('content')
    <style>
        a {
            text-decoration: none;
            color: black;
        }

        .activated {
            color: black;
            border-bottom: 2px solid !important;
        }
    </style>
    <div class="col-md-12 text-center">
        {{-- <a href="{{url('blog/page3/list')}}" class="{{request()->is('blog/page3/list') ? 'activated' : ''}} mx-5"> view blog</a> --}}
        {{-- <a href="{{ url('blog/viewblog') }}" class="{{ request()->is('blog/viewblog') ? 'activated' : '' }} mx-5"> view
            blog</a> --}}
        <a href="{{ url('blog/list') }}" class="{{ request()->is('blog/list') ? 'activated' : '' }} mx-3"> View list</a>
        <a href="{{ url('blog/view') }}" class="{{ request()->is('blog/view') ? 'activated' : '' }} mx-5"> View blog</a>
        <a href="{{ route('blog-add') }}" class="mt-4 h4 btn btn-dark">+ Add Blog</a>
        @if (session('success'))
            <div class="alert alert-success mt-3">{{ session('success') }}</div>
        @endif
        <div class="container p-2">
            <div class="row">
                <div class="col">
                    <div class="table-responsive">
                        <table class="table table-secondary table-hover">
                            <thead>
                                <tr>
                                    <th>Title</th>
                                    <th>Description</th>
                                    <th>Image</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($blogs as $blog)
                                    <tr>
                                        <td>{{ $blog->title }}</td>
                                        <td>{{ $blog->description }}</td>
                                        <td>
                                            @if ($blog->image)
                                                <img src="{{ asset('public/upload/blog/' . $blog->image) }}"
                                                    style="width: 100px; height:50px;">
                                            @else
                                                <span>No Image</span>
                                            @endif
                                        </td>
                                        @php
                                            $bgColor = '';
                                            switch ($blog->status) {
                                                case 'active':
                                                    $bgColor = 'bg-success';
                                                    break;
                                                case 'inactive':
                                                    $bgColor = 'bg-danger';
                                                    break;
                                                case 'pending':
                                                    $bgColor = 'bg-warning';
                                                    break;

                                                default:
                                                    $bgColor = 'bg-success';
                                                    break;
                                            }
                                        @endphp
                                        <td><a href=""
                                                class="btn text-white {{ $bgColor }}">{{ $blog->status }}</a>
                                        </td>
                                        <td>
                                            <a href="{{ route('blog-edit', $blog->id) }}" class="btn btn-success"><i
                                                    class="bi bi-pencil-square"></i></a>

                                            <a href="{{ route('blog-delete', $blog->id) }}" class="btn btn-danger"
                                                onclick="return confirm('Are you sure?')"><i
                                                    class="bi bi-trash3-fill"></i></a>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                        <div class="d-flex justify-content-center">
                        {{$data['code2']->links()}}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
