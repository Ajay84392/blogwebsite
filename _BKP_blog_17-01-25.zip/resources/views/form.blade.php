{{-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
<div class="fullscreen-container">
    <img src="{{ asset('public/image/abc43.png') }}" class="fullscreen-image w-100" alt="...">
    <div class="form-overlay" style="width:1140px; height:px;">
        <form>
            <div class="image-container">
                <img src="{{ asset('public/image/abc15.jpeg') }}" class="centered-image" alt="...">
            </div>
            <!-- Main Content Container -->
            <div class="container">
                <div class="">
                    <h1 class="text-primary">
                        Build a Business That Will Sell: From Valuations to a Successful Exit
                    </h1>
                    <p class="text-muted fs-5">
                        Tue, Jan 21, 2025 10:30 PM - 11:30 PM IST
                    </p>
                    <p class="text-primary">Show in My Time Zone</p>
                </div>
                <div class="d-flex">
                    <p>
                        Whether you've started your business already or you're just getting started, there's a lot on
                        your
                        plate. Starting and growing a business <br> requires a great idea, fundraising, market research,
                        and
                        finding customers, hiring, just to name a few. But here's one aspect of <br> ownership that many
                        entrepreneurs overlook: What it takes to build a structure to sell that business someday for
                        maximum value.
                        <img src="{{ asset('public/image/abc4.jpg') }}" class="" alt="...">
                    </p>
                    <p>If your business is one of your most significant assets, then it's essential to have a plan to
                        build and grow it into something buyers will <br> find irresistible.</p>
                    <p>Selling a business is a major milestone, and the process starts long before you list it. Learn
                        how to design operations, enhance profitability, and strategically position your business for a
                        successful sale—whether that's soon or years down the road.</p>
                    <p>Join us for a free webinar, Build a Business That Will Sell: From Valuations to a Successful
                        Exit, presented by Oracle NetSuite and Entrepreneur. Join moderator and communication AI
                        strategist Dr. Jill Schiefelbein in a conversation with seasoned business broker and serial
                        entrepreneur Ben Shaw on what buyers look for and how to maximize your business's value.</p>
                    <p>From streamlining operations to building recurring revenue streams, this session will dive deep
                        into strategies that make your business stand out in the market. Whether you're planning to sell
                        or future-proof your business, this webinar is packed with actionable advice to help you
                        succeed.</p>
                    <p>- Key roadblocks that prevent entrepreneurs from selling their businesses—and how to structure
                        yours to avoid these pitfalls.<br>
                        - Common red flags that make buyers hesitant and the proactive steps you can take to address
                        them with confidence.<br>
                        - Overlooked opportunities to boost your company's value, including why the number 2.5 is a
                        game-changer for your growth strategy.<br>
                        - Hot buttons that make your business more attractive to buyers, and how you can work those into
                        your business strategy.</p>
                    <p>*required Field</p>
                </div>
                <div class="d-flex justify-content-between">
                    <div class="col-md-6">
                        <label for="exampleFormControlInput1" class="form-label">First Name*</label>
                    </div>
                    <input type="email" class="form-control" style="width: 500px;" id="exampleFormControlInput1"
                        placeholder="">
                    <div class="col-md-6">
                        <label for="exampleFormControlInput1" class="form-label">Last Name*</label>
                    </div>
                    <input type="email" class="form-control mt-1 mx-2" style="width: 500px;"
                        id="exampleFormControlInput1" placeholder="">
                </div>
                <div class="d-flex justify-content-between">
                    <div class="col-md-6">
                        <label for="exampleFormControlInput1" class="form-label">First Name*</label>
                    </div>
                    <input type="email" class="form-control" style="width: 500px;" id="exampleFormControlInput1"
                        placeholder="">
                    <div class="col-md-6">
                        <label for="exampleFormControlInput1" class="form-label">Last Name*</label>
                    </div>
                    <input type="email" class="form-control mt-1 mx-2" style="width: 500px;"
                        id="exampleFormControlInput1" placeholder="">
                </div>
                <div class="d-flex justify-content-between">
                    <div class="col-md-6">
                        <label for="exampleFormControlInput1" class="form-label">What industry are you in?*</label>
                    </div>
                    <select name="state_crud" class="form-control input-group" style="width: 500px;" id="state_crud">
                        <option value="AN">Andaman and Nicobar</option>
                        <option value="AP">Andhra Pradesh</option>
                        <option value="AR">Arunachal Pradesh</option>
                        <option value="AS">Assam</option>
                        <option value="BR">Bihar</option>
                        <option value="CH">Chandigarh</option>
                        <option value="CG">Chhattisgarh</option>
                        <option value="DL">Delhi</option>
                        <option value="GA">Goa</option>
                        <option value="GJ">Gujarat</option>
                        <option value="HR">Haryana</option>
                        <option value="HP">Himachal Pradesh</option>
                        <option value="JK">Jammu and Kashmir</option>
                        <option value="JH">Jharkhand</option>
                        <option value="KA">Karnataka</option>
                        <option value="KL">Kerala</option>
                        <option value="LA">Ladakh</option>
                        <option value="LD">Lakshadweep(UT)</option>
                        <option value="MP">Madhya Pradesh</option>
                        <option value="MH">Maharashtra</option>
                        <option value="MN">Manipur</option>
                        <option value="ML">Meghalaya</option>
                        <option value="MZ">Mizoram</option>
                        <option value="NL">Nagaland</option>
                        <option value="OD">Odisha</option>
                        <option value="PY">Pondicherry</option>
                        <option value="PB">Punjab</option>
                        <option value="RJ">Rajasthan</option>
                        <option value="SK">Sikkim</option>
                        <option value="TN">Tamil Nadu</option>
                        <option value="TR">Tripura</option>
                        <option value="DD">UT of DNH and DD</option>
                        <option value="UK">Uttarakhand</option>
                        <option value="UP">Uttar Pradesh</option>
                        <option value="WB">West Bengal</option>
                    </select>
                </div>
                <div class="d-flex justify-content-between">
                    <div class="col-md-6">
                        <label for="exampleFormControlInput1" class="form-label">Are you a business owner?*</label>
                    </div>
                    <select name="state_crud" class="form-control input-group" style="width: 500px;"
                        id="state_crud">
                        <option value="AN">Yes</option>
                        <option value="AP">No</option>
                    </select>
                </div>
                <div class="col-md-6">
                    <label for="exampleFormControlInput1" class="form-label">If yes, what is your annual
                        revenue?</label>
                </div>
                <input type="email" class="form-control mt-1 mx-2" style="width: 500px;"
                    id="exampleFormControlInput1" placeholder="">
                <div class="form-check">
                    <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                    <label class="form-check-label" for="flexCheckDefault">
                        By filling and submitting this form you understand and agree that the use of Oracle's web site
                        is subject to the oracle.com terms of use:
                        https://www.oracle.com/us/legal/privacy/privacy-policy/index.html. Additional details regarding
                        Oracle’s collection and use of your personal information, including information about access,
                        retention, rectification, deletion, security, cross-border transfers and other topics, is
                        available in the oracle privacy policy:
                        https://www.oracle.com/us/legal/privacy/privacy-policy/index.html
                    </label>
                </div>
                <div class="text-primary mt-5">
                    <button type="register" class="form-control text-primary"
                        style="width: 110px; height:50px;">Register</button>
                </div>
            </div>
        </form>
    </div>
</div>
<div class="additional-content" style="background-color: #444444; color: #ffffff;">
    <h5>©2025 GoTo, Inc. All rights reserved.</h5>
    <h5 class="d-flex justify-content-center align-items-center">
        View the <span class="text-primary ms-1">GoTo Webinar Privacy Policy</span>
    </h5>
    <h5>To review the webinar organizer's privacy policy or opt out of their other communications, contact the webinar
        organizer directly.</h5>
    <h5>Safeguarding your email address and webinar registration information is taken seriously at GoTo Webinar. GoTo
        Webinar will not sell or rent this information.</h5>
</div>
<style>
    .fullscreen-container {
        position: relative;
        width: 100%;
        overflow: hidden;
    }
    .additional-content {
       
        padding: 20px;
        color: #f9f9f9;
    }

    .mt-5 {
        margin-top: 5rem;
    }
    .text-white {
        color: #f9f9f9;
    }
    .text-primary {
        color: #589DDE;
        text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.2);
    }
    .fullscreen-image {
        width: 1525px;
        height: 1800px;
    }
    .form-overlay {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        background-color: rgba(255, 255, 255, 0.8);
        padding: 20px;
        box-shadow: 0 3px 7px rgba(0, 0, 0, 0.3);
        height: auto;
        overflow-y: auto;
    }
    .image-container {
        display: flex;
        justify-content: center;
        align-items: center;
    }
    .centered-image {
        width: 25rem;
        height: 250px;
        object-fit: contain;
    }
    h1 {
        margin-bottom: 10px;
    }
    p.text-primary {
        cursor: pointer;
    }
    body {
        margin: 0 !important;
        width: 100%;
    }
</style>
 --}}
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Webinar Form</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <style>
        .fullscreen-container {
            position: relative;
            width: 100%;
            overflow: hidden;
        }

        .fullscreen-image {
            width: 100%;
            /* height: auto; */
            height: 2200px;
        }

        .form-overlay {
            position: absolute;
            top: 49%;
            left: 50%;
            transform: translate(-50%, -50%);
            background-color: rgba(255, 255, 255, 0.95);
            padding: 30px;
            /* border-radius: 10px; */
            box-shadow: 0 2px 7px rgba(0, 0, 0, 0.3);
            max-width: 1190px;
            width: 100%;
        }

        .additional-content {
            background-color: #444444;
            color: #ffffff;
            padding: 30px;
            /* text-align: center; */
        }

        .image-container {
            text-align: center;
            margin-bottom: 25px;
        }

        .centered-image {
            width: 400px;
            height: auto;
            border-radius: 5px;
        }

        .text-primary {
            color: #589DDE;
            text-decoration: none;
            cursor: pointer;
        }

        .form-check-label a {
            color: #589DDE;
            text-decoration: underline;
        }

        .btn-primary {
            background-color: #589DDE;
            border: none;
        }
    </style>
</head>

<body>
    <div class="fullscreen-container">
        <img src="{{ asset('public/image/abc43.png') }}" class="fullscreen-image" alt="...">
        <div class="form-overlay" style="height: 2050px;">
            <div class="image-container">
                <img src="{{ asset('public/image/abc15.jpeg') }}" class="centered-image" alt="...">
            </div>
            <form>
                <h2 class="text-primary">Build a Business That Will Sell: From Valuations to a Successful Exit</h2>
                <p class="text-muted mt-4">Tue, Jan 21, 2025 | 10:30 PM - 11:30 PM IST</p>
                <p class="text-primary">Show in My Time Zone</p>
                <div class="">
                    <div class="d-flex">
                        <p>
                            Whether you've started your business already or you're just getting started, there's a lot
                            on
                            your
                            plate.<br> Starting and growing a business requires a great idea, fundraising, market
                            research,
                            and
                            finding customers<br> hiring, just to name a few. But here's one aspect of ownership that
                            many
                            entrepreneurs overlook: <br>What it takes to build a structure to sell that business someday
                            for
                            maximum value.
                            
                        </p>
                        <div class="d-flex justify-content-end">
                            <img src="{{ asset('public/image/abc4.jpg') }}" class="mx-5" alt="...">
                        </div>
                    </div>
                    <p>If your business is one of your most significant assets, then it's essential to have a plan
                        to
                        build and grow it into something buyers will find irresistible.</p>
                    <p>Selling a business is a major milestone, and the process starts long before you list it.
                        Learn
                        how to design operations, enhance profitability, and strategically position your business
                        for a
                        successful sale—whether that's soon or years down the road.</p>
                    <p>Join us for a free webinar, Build a Business That Will Sell: From Valuations to a Successful
                        Exit, presented by Oracle NetSuite and Entrepreneur. Join moderator and communication AI
                        strategist Dr. Jill Schiefelbein in a conversation with seasoned business broker and serial
                        entrepreneur Ben Shaw on what buyers look for and how to maximize your business's value.</p>
                    <p>From streamlining operations to building recurring revenue streams, this session will dive
                        deep
                        into strategies that make your business stand out in the market. Whether you're planning to
                        sell
                        or future-proof your business, this webinar is packed with actionable advice to help you
                        succeed.</p>
                    <p>- Key roadblocks that prevent entrepreneurs from selling their businesses—and how to
                        structure
                        yours to avoid these pitfalls.<br>
                        - Common red flags that make buyers hesitant and the proactive steps you can take to address
                        them with confidence.<br>
                        - Overlooked opportunities to boost your company's value, including why the number 2.5 is a
                        game-changer for your growth strategy.<br>
                        - Hot buttons that make your business more attractive to buyers, and how you can work those
                        into
                        your business strategy.</p>
                    <p>*required Field</p>
                </div>
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="firstName" class="form-label">First Name*</label>
                        <input type="text" id="firstName" class="form-control" style="width: 535px;" placeholder="">
                    </div>
                    <div class="col-md-6">
                        <label for="lastName" class="form-label">Last Name*</label>
                        <input type="text" id="lastName" class="form-control" style="width: 525px;" placeholder="">
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="firstName" class="form-label">Email Address*</label>
                        <input type="text" id="firstName" class="form-control" style="width: 535px;" placeholder="">
                    </div>
                    <div class="col-md-6 mb-3">
                        <div class="d-flex justify-content-between">
                            <div class="col-md-6">
                                <label for="exampleFormControlInput1" class="form-label">Country/Region*</label>
                                <select name="state_crud" class="form-control input-group" style="width: 525px;"
                                    id="state_crud">
                                    <option value="AN">Choose One...</option>
                                    <option value="AN">Andaman and Nicobar</option>
                                    <option value="AP">Andhra Pradesh</option>
                                    <option value="AR">Arunachal Pradesh</option>
                                    <option value="AS">Assam</option>
                                    <option value="BR">Bihar</option>
                                    <option value="CH">Chandigarh</option>
                                    <option value="CG">Chhattisgarh</option>
                                    <option value="DL">Delhi</option>
                                    <option value="GA">Goa</option>
                                    <option value="GJ">Gujarat</option>
                                    <option value="HR">Haryana</option>
                                    <option value="HP">Himachal Pradesh</option>
                                    <option value="JK">Jammu and Kashmir</option>
                                    <option value="JH">Jharkhand</option>
                                    <option value="KA">Karnataka</option>
                                    <option value="KL">Kerala</option>
                                    <option value="LA">Ladakh</option>
                                    <option value="LD">Lakshadweep(UT)</option>
                                    <option value="MP">Madhya Pradesh</option>
                                    <option value="MH">Maharashtra</option>
                                    <option value="MN">Manipur</option>
                                    <option value="ML">Meghalaya</option>
                                    <option value="MZ">Mizoram</option>
                                    <option value="NL">Nagaland</option>
                                    <option value="OD">Odisha</option>
                                    <option value="PY">Pondicherry</option>
                                    <option value="PB">Punjab</option>
                                    <option value="RJ">Rajasthan</option>
                                    <option value="SK">Sikkim</option>
                                    <option value="TN">Tamil Nadu</option>
                                    <option value="TR">Tripura</option>
                                    <option value="DD">UT of DNH and DD</option>
                                    <option value="UK">Uttarakhand</option>
                                    <option value="UP">Uttar Pradesh</option>
                                    <option value="WB">West Bengal</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="firstName" class="form-label">Phone Number*</label>
                            <input type="text" id="firstName" class="form-control" style="width: 535px;"
                                placeholder="">
                        </div>
                        <div class="col-md-6">
                            <label for="lastName" class="form-label">Organization*</label>
                            <input type="text" id="lastName" class="form-control" style="width: 535px;"
                                placeholder="">
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="firstName" class="form-label">Job Title*</label>
                            <input type="text" id="firstName" class="form-control" style="width: 535px;"
                                placeholder="">
                        </div>
                        <div class="col-md-6">
                            <label for="lastName" class="form-label">Purchasing Time
                                Frame*</label>
                            <select name="state_crud" class="form-control input-group" style="width: 535px;"
                                id="state_crud">
                                <option value="AN">Choose One...</option>
                                <option value="AN">Andaman and Nicobar</option>
                                <option value="AP">Andhra Pradesh</option>
                                <option value="AR">Arunachal Pradesh</option>
                                <option value="AS">Assam</option>
                                <option value="BR">Bihar</option>
                                <option value="CH">Chandigarh</option>
                                <option value="CG">Chhattisgarh</option>
                                <option value="DL">Delhi</option>
                                <option value="GA">Goa</option>
                                <option value="GJ">Gujarat</option>
                                <option value="HR">Haryana</option>
                                <option value="HP">Himachal Pradesh</option>
                                <option value="JK">Jammu and Kashmir</option>
                                <option value="JH">Jharkhand</option>
                                <option value="KA">Karnataka</option>
                                <option value="KL">Kerala</option>
                                <option value="LA">Ladakh</option>
                                <option value="LD">Lakshadweep(UT)</option>
                                <option value="MP">Madhya Pradesh</option>
                                <option value="MH">Maharashtra</option>
                                <option value="MN">Manipur</option>
                                <option value="ML">Meghalaya</option>
                                <option value="MZ">Mizoram</option>
                                <option value="NL">Nagaland</option>
                                <option value="OD">Odisha</option>
                                <option value="PY">Pondicherry</option>
                                <option value="PB">Punjab</option>
                                <option value="RJ">Rajasthan</option>
                                <option value="SK">Sikkim</option>
                                <option value="TN">Tamil Nadu</option>
                                <option value="TR">Tripura</option>
                                <option value="DD">UT of DNH and DD</option>
                                <option value="UK">Uttarakhand</option>
                                <option value="UP">Uttar Pradesh</option>
                                <option value="WB">West Bengal</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <label for="lastName" class="form-label">What industry are you in?*</label>
                        <select name="state_crud" class="form-control input-group" style="width: 1100px;"
                            id="state_crud">
                            <option value="AN">Choose One...</option>
                            <option value="AN">Andaman and Nicobar</option>
                            <option value="AP">Andhra Pradesh</option>
                            <option value="AR">Arunachal Pradesh</option>
                            <option value="AS">Assam</option>
                            <option value="BR">Bihar</option>
                            <option value="CH">Chandigarh</option>
                            <option value="CG">Chhattisgarh</option>
                            <option value="DL">Delhi</option>
                            <option value="GA">Goa</option>
                            <option value="GJ">Gujarat</option>
                            <option value="HR">Haryana</option>
                            <option value="HP">Himachal Pradesh</option>
                            <option value="JK">Jammu and Kashmir</option>
                            <option value="JH">Jharkhand</option>
                            <option value="KA">Karnataka</option>
                            <option value="KL">Kerala</option>
                            <option value="LA">Ladakh</option>
                            <option value="LD">Lakshadweep(UT)</option>
                            <option value="MP">Madhya Pradesh</option>
                            <option value="MH">Maharashtra</option>
                            <option value="MN">Manipur</option>
                            <option value="ML">Meghalaya</option>
                            <option value="MZ">Mizoram</option>
                            <option value="NL">Nagaland</option>
                            <option value="OD">Odisha</option>
                            <option value="PY">Pondicherry</option>
                            <option value="PB">Punjab</option>
                            <option value="RJ">Rajasthan</option>
                            <option value="SK">Sikkim</option>
                            <option value="TN">Tamil Nadu</option>
                            <option value="TR">Tripura</option>
                            <option value="DD">UT of DNH and DD</option>
                            <option value="UK">Uttarakhand</option>
                            <option value="UP">Uttar Pradesh</option>
                            <option value="WB">West Bengal</option>
                        </select>
                    </div>
            </form>
        </div>
        <div class="col-md-6">
            <label for="lastName" class="form-label">Are you a business owner?*</label>
            <select name="state_crud" class="form-control input-group" style="width: 1100px;" id="state_crud">
                <option value="AN">Choose One...</option>
                <option value="AN">Andaman and Nicobar</option>
                <option value="AP">Andhra Pradesh</option>
                <option value="AR">Arunachal Pradesh</option>
                <option value="AS">Assam</option>
                <option value="BR">Bihar</option>
                <option value="CH">Chandigarh</option>
                <option value="CG">Chhattisgarh</option>
                <option value="DL">Delhi</option>
                <option value="GA">Goa</option>
                <option value="GJ">Gujarat</option>
                <option value="HR">Haryana</option>
                <option value="HP">Himachal Pradesh</option>
                <option value="JK">Jammu and Kashmir</option>
                <option value="JH">Jharkhand</option>
                <option value="KA">Karnataka</option>
                <option value="KL">Kerala</option>
                <option value="LA">Ladakh</option>
                <option value="LD">Lakshadweep(UT)</option>
                <option value="MP">Madhya Pradesh</option>
                <option value="MH">Maharashtra</option>
                <option value="MN">Manipur</option>
                <option value="ML">Meghalaya</option>
                <option value="MZ">Mizoram</option>
                <option value="NL">Nagaland</option>
                <option value="OD">Odisha</option>
                <option value="PY">Pondicherry</option>
                <option value="PB">Punjab</option>
                <option value="RJ">Rajasthan</option>
                <option value="SK">Sikkim</option>
                <option value="TN">Tamil Nadu</option>
                <option value="TR">Tripura</option>
                <option value="DD">UT of DNH and DD</option>
                <option value="UK">Uttarakhand</option>
                <option value="UP">Uttar Pradesh</option>
                <option value="WB">West Bengal</option>
            </select>
        </div>
        <div class="col-md-6 mt-3">
            <label for="lastName" class="form-label">If yes, what is your annual revenue?*</label>
            <select name="state_crud" class="form-control input-group" style="width: 1100px;" id="state_crud">
                <option value="AN">Choose One...</option>
                <option value="AN">Andaman and Nicobar</option>
                <option value="AP">Andhra Pradesh</option>
                <option value="AR">Arunachal Pradesh</option>
                <option value="AS">Assam</option>
                <option value="BR">Bihar</option>
                <option value="CH">Chandigarh</option>
                <option value="CG">Chhattisgarh</option>
                <option value="DL">Delhi</option>
                <option value="GA">Goa</option>
                <option value="GJ">Gujarat</option>
                <option value="HR">Haryana</option>
                <option value="HP">Himachal Pradesh</option>
                <option value="JK">Jammu and Kashmir</option>
                <option value="JH">Jharkhand</option>
                <option value="KA">Karnataka</option>
                <option value="KL">Kerala</option>
                <option value="LA">Ladakh</option>
                <option value="LD">Lakshadweep(UT)</option>
                <option value="MP">Madhya Pradesh</option>
                <option value="MH">Maharashtra</option>
                <option value="MN">Manipur</option>
                <option value="ML">Meghalaya</option>
                <option value="MZ">Mizoram</option>
                <option value="NL">Nagaland</option>
                <option value="OD">Odisha</option>
                <option value="PY">Pondicherry</option>
                <option value="PB">Punjab</option>
                <option value="RJ">Rajasthan</option>
                <option value="SK">Sikkim</option>
                <option value="TN">Tamil Nadu</option>
                <option value="TR">Tripura</option>
                <option value="DD">UT of DNH and DD</option>
                <option value="UK">Uttarakhand</option>
                <option value="UP">Uttar Pradesh</option>
                <option value="WB">West Bengal</option>
            </select>
        </div>
        <div class="form-check mt-4">
            <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
            <label class="form-check-label" for="flexCheckDefault">
                By filling and submitting this form you understand and agree that the use of Oracle's web site
                is subject to the blog terms of use:
                <span class="text-primary"> http://localhost/Blog/ </span> Additional details regarding
                Oracle’s collection and use of your personal information, including information about access,
                retention, rectification, deletion, security, cross-border transfers and other topics, is
                available in the oracle privacy policy:
                <span class="text-primary">http://localhost/Blog/login</span>
            </label>
        </div>
        <div class="text-center mt-5">
            <button type="submit" class="btn btn-primary fs-5" style="height:60px; width:170px;">Register</button>
        </div>
        </form>
    </div>
    </div>
    <div class="" style="background-color: #444444; color: #ffffff;">
        <div class="container">
            <div class="mx-5 additional-content">
                <h6>©2025 GoTo, Inc. All rights reserved.</h6>
                <h6 class="">
                    View the <span class="text-primary">GoTo Webinar Privacy Policy</span>
                </h6>
                <h6>To review the webinar organizer's privacy policy or opt out of their other communications, contact
                    the
                    webinar
                    organizer directly.</h6>
                <h6>Safeguarding your email address and webinar registration information is taken seriously at GoTo
                    Webinar.
                    GoTo
                    Webinar will not sell or rent this information.</h6>
            </div>
        </div>
    </div>
</body>

</html>