@extends('layout.default')
@section('content')
    <div class="container p-5">
        <div class="row">
            <div class="col">
                <div class="table-responsive">
                    <table class="table table-secondary table-hover">
                        <thead>
                            <tr>
                                <th class="h6">ID</th>
                                <th class="h6">FULL NAME</th>
                                <th class="h6">Date of Birth</th>
                                <th class="h6">State</th>
                                <th class="h6">Contact</th>
                                <th class="h6">Email</th>
                                <th class="h6">Password</th>
                                <th class="h6">Edit</th>
                                <th class="h6">Delete</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($data['Cruds'] as $d)
                                <tr class="">
                                    <td scope="row">{{ $d->id }}</td>
                                    <td>{{ $d->full_name }}</td>
                                    <td>{{ $d->dob }}</td>
                                    <td>{{ $d->state }}</td>
                                    <td>{{ $d->contact }}</td>
                                    <td>{{ $d->email }}</td>
                                    <td>{{ $d->password }}</td>
                                    <td><a href="{{ route('crud-edit', ['id' => $d->id]) }}"><i
                                                class=" btn btn-success bi bi-pen"></i></a>
                                    </td>
                                    <td><a href="{{ route('crud-delete', ['id' => $d->id]) }}"><i
                                                class="btn btn-danger bi bi-trash3"></i></a> </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                    <div class="d-flex justify-content-center">{{ $data['Cruds']->links() }}</div>
                </div>
            </div>
        </div>
    </div>
@endsection
@section('css')
@endsection
@section('script')
@endsection

