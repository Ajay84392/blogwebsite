{{-- @extends('layout.default')
@section('content') --}}
<html lang="en">
<head>
    <title>Title</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous" />
    <link rel="stylesheet" href="{{ asset('./public/template/frontend_css.css') }}">
</head>
    <header class="d-flex flex-wrap justify-content-start">
        <a href="/" class="d-flex align-items-center text-decoration-none">
        </a>
    </header>
    @if (session()->has('flash_notification.primary'))
        <div class="alert alert-primary" id="alert1">{!! session('flash_notification.primary') !!}</div>
    @endif
    <div class="car">
        <div>
            <img src="{{ asset('public/image/abc6.webp') }}" class="d-block" alt="..."
                style="height: 1000px; width: 100%;">
        </div>
        <div class="card-img-overlay mt-5">
            <a href="{{ route('crud-detail') }}" class="btn btn-dark mx-3">Registration Detail</a>
            <div class="card center mt-5"
                style="height:fit-content; width: 35rem;margin-left:auto;margin-right:auto;">
                <div class="card-body">
                    <form action="{{ URL::current() }}" method="post" class="needs-validation" novalidate>
                        @csrf
                        <h5 class="card-title fs-2 text-center">Registration Form </h5>
                        <div class="mb-3 has-validation ">
                            <label for="exampleFormControlInput1" class="form-label">Full Name</label>
                            <input type="text" class="form-control input-group " id="f_name" name="f_name"
                                placeholder="Enter Full Name">
                            <div class="invalid-feedback">
                                * Required Field.
                            </div>
                        </div>
                        <div class="mb-3">
                            <label for="exampleFormControlInput1" class="form-label">Date Of Birth</label>
                            <input type="date" class="form-control input-group" id="date_of_birth" name="date_of_birth"
                                placeholder="Enter D.O.B">
                            <div class="invalid-feedback">
                                * Required Field.
                            </div>
                        </div>
                        <div class="mb-3">
                            <label for="exampleFormControlInput1" class="form-label">State</label>
                            <select name="state_crud" class="form-control input-group " id="state_crud">
                                <option value="AN">Choose One...</option>
                                <option value="AN">Andaman and Nicobar</option>
                                <option value="AP">Andhra Pradesh</option>
                                <option value="AR">Arunachal Pradesh</option>
                                <option value="AS">Assam</option>
                                <option value="BR">Bihar</option>
                                <option value="CH">Chandigarh</option>
                                <option value="CG">Chhattisgarh</option>
                                <option value="DL">Delhi</option>
                                <option value="GA">Goa</option>
                                <option value="GJ">Gujarat</option>
                                <option value="HR">Haryana</option>
                                <option value="HP">Himachal Pradesh</option>
                                <option value="JK">Jammu and Kashmir</option>
                                <option value="JH">Jharkhand</option>
                                <option value="KA">Karnataka</option>
                                <option value="KL">Kerala</option>
                                <option value="LA">Ladakh</option>
                                <option value="LD">Lakshadweep(UT)</option>
                                <option value="MP">Madhya Pradesh</option>
                                <option value="MH">Maharashtra</option>
                                <option value="MN">Manipur</option>
                                <option value="ML">Meghalaya</option>
                                <option value="MZ">Mizoram</option>
                                <option value="NL">Nagaland</option>
                                <option value="OD">Odisha</option>
                                <option value="PY">Pondicherry</option>
                                <option value="PB">Punjab</option>
                                <option value="RJ">Rajasthan</option>
                                <option value="SK">Sikkim</option>
                                <option value="TN">Tamil Nadu</option>
                                <option value="TR">Tripura</option>
                                <option value="DD">UT of DNH and DD</option>
                                <option value="UK">Uttarakhand</option>
                                <option value="UP">Uttar Pradesh</option>
                                <option value="WB">West Bengal</option>
                            </select>
                            <div class="invalid-feedback">
                                * Required Field.
                            </div>
                        </div>
                        <div class="mb-3">
                            <label for="exampleFormControlInput1" class="form-label">Contact</label>
                            <input type="number" class="form-control input-group " id="contact_no" name="contact_no"
                                placeholder="Enter Number">
                            <div class="invalid-feedback">
                                * Min 10 Digits Field.
                            </div>
                        </div>
                        <div class="mb-3">
                            <label for="exampleFormControlInput1" class="form-label">Email address</label>
                            <input type="email" class="form-control input-group " id="email_id" name="email_id"
                                placeholder="name@example.com">
                            <div class="invalid-feedback">
                                * Required Field.
                            </div>
                        </div>
                        <div class="mb-3">
                            <label for="exampleFormControlTextarea1" class="form-label">Password</label>
                            <input type="password" class="form-control input-group " id="password_pass"
                                name="password_pass" rows="3">
                            <div class="invalid-feedback">
                                *Your password must be 8-20 characters long, contain letters and numbers, and must not
                                contain spaces, special characters, or emoji.
                            </div>
                        </div>
                        <div class="text-center">
                            <button type="submit" class="mt-2 mb-2 form-control bg-dark text-white">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
{{-- @endsection --}}
@section('css')
    <style>
        .start-css {}
    </style>
@endsection
@section('script')
    <script>
        document.getElementById('f_name').addEventListener('blur', function() {
            if (this.value.trim() === '') {
                this.classList.add('is-invalid');
            } else {
                this.classList.remove('is-invalid');
            }
        });
    </script>
    <script>
        document.getElementById('email_id').addEventListener('blur', function() {
            if (this.value.trim() === '') {
                this.classList.add('is-invalid');
            } else {
                this.classList.remove('is-invalid');
            }
        });
    </script>
    <script>
        document.getElementById('date_of_birth').addEventListener('blur', function() {
            if (this.value.trim() === '') {
                this.classList.add('is-invalid');
            } else {
                this.classList.remove('is-invalid');
            }
        });
    </script>
    <script>
        document.getElementById('state_crud').addEventListener('blur', function() {
            if (this.value.trim() === '') {
                this.classList.add('is-invalid');
            } else {
                this.classList.remove('is-invalid');
            }
        });
    </script>
    <script>
        document.getElementById('contact_no').addEventListener('blur', function() {
            if (this.value.trim() === '') {
                this.classList.add('is-invalid');
            } else {
                this.classList.remove('is-invalid');
            }
        });
    </script>
    <script>
        document.getElementById('password_pass').addEventListener('blur', function() {
            if (this.value.trim() === '') {
                this.classList.add('is-invalid');
            } else {
                this.classList.remove('is-invalid');
            }
        });
    </script>
    <script>
        setTimeout(() => {
            document.getElementById("alert1").style.display = "none";
        }, 4000);
    </script>
@endsection

{{-- <!doctype html>
<html lang="en">
<head>
    <title>Title</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous" />
    <link rel="stylesheet" href="{{ asset('./public/template/frontend_css.css') }}">
</head>
<body>
    <main>
        @if (session('flash_notification.success'))
            <div class="alert alert-success flash-message">
                {!! session('flash_notification.success') !!}
            </div>
        @endif

        @if (session('flash_notification.error'))
            <div class="alert alert-danger flash-message">
                {!! session('flash_notification.error') !!}
            </div>
        @endif
        <div>
            <img src="{{ asset('public/image/abc6.webp') }}" class="d-block" alt="..."
                style="height: 800px; width: 100%;">
        </div>
        <div class="card-img-overlay mt-5">
            <a href="{{ route('detail') }}" class="btn btn-dark mx-3">Show Detail</a>
            <div class="card bg-white center mt-5"
                style="border-radius:12px; height:fit-content; width: 30rem;margin-left:auto;margin-right:auto;">
                <div class="card-body">
                    <form action="{{ url(URL::current()) }}" method="post" class="needs-validation"
                        autocomplete="new-password" novalidate>
                        @csrf
                        <div class="text-center">
                            <svg xmlns="http://www.w3.org/2000/svg" width="60" height="60" fill="currentColor"
                                class="bi bi-person-circle" viewBox="0 0 16 16">
                                <path d="M11 6a3 3 0 1 1-6 0 3 3 0 0 1 6 0" />
                                <path fill-rule="evenodd"
                                    d="M0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8m8-7a7 7 0 0 0-5.468 11.37C3.242 11.226 4.805 10 8 10s4.757 1.225 5.468 2.37A7 7 0 0 0 8 1" />
                            </svg>
                        </div>
                        <div class="">
                            <i class="bi fs-5 bi-envelope-fill"></i>
                            <label for="exampleFormControlInput2" class="mt-2 h6  form-label">Email Id</label>
                            <input type="email" class="form-control" id="email" name="email"
                                autocomplete="new-password" placeholder="name@example.com">
                            <div class="invalid-feedback">
                                * Required Field.
                            </div>
                        </div>
                        <div class="mb-3 mt-2">
                            <i class="bi fs-5 bi-lock-fill"></i>
                            <label for="exampleFormControlTextarea1" class="mt-3 h6 form-label">Password</label>
                            <input type="password" class="form-control" id="password" name="password"
                                autocomplete="new-password" rows="3">
                            <div class="invalid-feedback">
                                *Your password must be 8-20 characters long, contain letters and numbers, and must not
                                contain spaces, special characters.
                            </div>
                        </div>
                        <div class="text-center">
                            <button type="Login" class="mt-3 bg-dark form-control btn btn-primary">Login</button>
                        </div>
                        <div class="mt-2 form-check d-flex align-items-center justify-content-between">
                            <div class="d-flex align-items-center">
                                <a href="{{ 'register' }}" class="no-underline text-dark" aria-current="page">New Register</a>
                            </div>
                            <a href="{{ route('blog-forget') }}" class="text-dark">Forgot Password</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </main>
    <footer>
    </footer>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"
        integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous">
    </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js"
        integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+" crossorigin="anonymous">
    </script>

    <script>
        document.getElementById('name').addEventListener('blur', function() {
            if (this.value.trim() === '') {
                this.classList.add('is-invalid');
            } else {
                this.classList.remove('is-invalid');
            }
        });
    </script>
    <script>
        document.getElementById('email').addEventListener('blur', function() {
            if (this.value.trim() === '') {
                this.classList.add('is-invalid');
            } else {
                this.classList.remove('is-invalid');
            }
        });
    </script>
    <script>
        document.getElementById('password').addEventListener('blur', function() {
            if (this.value.trim() === '') {
                this.classList.add('is-invalid');
            } else {
                this.classList.remove('is-invalid');
            }
        });
    </script>
    <script>
        setTimeout(() => {
            document.getElementById("alert").style.display = "none";
        }, 5000);
    </script>
    <script>
        setTimeout(() => {
            const flashMessages = document.querySelectorAll('.flash-message');
            flashMessages.forEach(msg => msg.style.display = 'none');
        }, 10000); 
    </script>
</body>
</html> --}}
