@extends('layout.default')
@section('content')
    <header class="d-flex flex-wrap justify-content-start py-2" style="height:55px;">
        <a href="/" class="d-flex align-items-center link-body-emphasis text-decoration-none">
            
        </a>
        <ul class="">
             <a href="{{ route('detail') }}" class="btn btn-primary">Registration Detail</a>
        </ul>
    </header>
    @if (session()->has('flash_notification.primary'))
        <div class="alert alert-primary" id="alert2">{!! session('flash_notification.primary') !!}</div>
    @endif
    <div class="card text-bg-dark ">
        <div>
            <img src="{{ asset('public/image/abc3.jpeg') }}" class="d-block" alt="..."
                style="height: 800px; width: 100%;">
        </div>
        <div class="card-img-overlay">
            <div class="card mt-5" style="height:fit-content; width: 30rem;margin-left:auto;margin-right:auto;">
                <div class="card-body">
                    <form action="{{ url(URL::current()) }}" method="post">
                        @csrf
                        <h5 class="card-title fs-2 text-center">Update Form</h5>
                        <div class="mb-3">
                            <label for="exampleFormControlInput1" class="form-label">Full Name</label>
                            <input type="text" class="form-control" id="f_name" name="f_name"
                                placeholder="Enter Full Name" value="{{ $data['Crud']->full_name }}">
                        </div>
                        <div class="mb-3">
                            <label for="exampleFormControlInput1" class="form-label">Date of Birth</label>
                            <input type="text" class="form-control" id="date_of_birth" name="date_of_birth"
                                placeholder="Enter DOB" value="{{ $data['Crud']->dob }}">
                        </div>
                        <div class="mb-3">
                            <label for="exampleFormControlInput1" class="form-label">State</label>
                            <input type="text" class="form-control" id="state_crud" name="state_crud"
                                placeholder="Enter state" value="{{ $data['Crud']->state }}">
                        </div>
                        <div class="mb-3">
                            <label for="exampleFormControlInput1" class="form-label">Contact</label>
                            <input type="text" class="form-control" id="contact_no" 
                                required name="contact_no" placeholder="Enter contact" value="{{ $data['Crud']->contact }}">
                        </div>
                        <div class="mb-3">
                            <label for="exampleFormControlInput1" class="form-label">Email address</label>
                            <input type="email" class="form-control" id="email_id" name="email_id"
                                value="{{ $data['Crud']->email }}" placeholder="name@example.com">
                        </div>
                        <div class="mb-3">
                            <label for="exampleFormControlTextarea1" class="form-label">Password</label>
                            <input type="password" class="form-control" id="password_pass" name="password_pass"
                                rows="3" value="{{ $data['Crud']->password }}">
                        </div>
                        <div class="text-center">
                            <button type="submit" class="mt-2 form-control btn btn-success">Update</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection
@section('css')
    <style>
        .start-css {}
    </style>
@endsection
@section('script')
@endsection
