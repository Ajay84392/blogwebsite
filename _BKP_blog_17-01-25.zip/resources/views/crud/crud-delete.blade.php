    
@extends('layout.default')
@section('content')
    
<header class="d-flex flex-wrap justify-content-start py-4" style="height:100px;">
    <a href="/" class="d-flex align-items-center link-body-emphasis text-decoration-none">
        <svg class="bi me-2" width="40" height="32">
            <use xlink:href="#bootstrap" />
        </svg>
        <span class="fs-4"></span>
    </a>
    <ul class="nav nav-pills">
        <li class="nav-item h4"> <a href="{{ route('detail') }}" class="btn btn-info">Registration Detail</a></li>
    </ul>
</header>

@endsection
@section('css')
@endsection
@section('script')
@endsection



