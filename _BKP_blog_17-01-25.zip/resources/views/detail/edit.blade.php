<!doctype html>
<html lang="en">
<head>
    <title>Title</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous" />
    <link rel="stylesheet" href="{{ asset('./public/template/frontend_css.css') }}">
</head>
<div>
    <img src="{{ asset('public/image/abc6.webp') }}" class="d-block" alt="..." style="height: 800px; width: 100%;">
</div>
<div class="card-img-overlay p-5 mt-5 ">
    <div class="card mt-5 " style="height:fit-content; width: 30rem;margin-left:auto;margin-right:auto;">
        <div class="card-body">
            <form action="{{ url(URL::current()) }}" method="post">
                @csrf
                <div class="text-center">
                    <svg xmlns="http://www.w3.org/2000/svg" width="60" height="60" fill="currentColor"
                        class="bi bi-person-circle" viewBox="0 0 16 16">
                        <path d="M11 6a3 3 0 1 1-6 0 3 3 0 0 1 6 0" />
                        <path fill-rule="evenodd"
                            d="M0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8m8-7a7 7 0 0 0-5.468 11.37C3.242 11.226 4.805 10 8 10s4.757 1.225 5.468 2.37A7 7 0 0 0 8 1" />
                    </svg>
                </div>
                <h5 class="card-title fs-3 text-center">Edit User</h5>
                <div class="mb-3">
                    <label for="exampleFormControlInput1" class="form-label">Full Name</label>
                    <input type="text" class="form-control" id="full_name" name="full_name" placeholder="Enter Name">
                </div>
                <div class="mb-3 mt-2">
                    <i class="bi fs-5 bi-person-circle"></i>
                    <label for="exampleFormControlInput1" class="h6 form-label">Date of Birth</label>
                    <input type="date" class="form-control" id="date_of_birth" name="date_of_birth"
                        placeholder="Enter D.O.B">
                </div>
                <div class="mb-3">
                    <label for="exampleFormControlInput1" class="form-label">Email address</label>
                    <input type="email" class="form-control" id="email" name="email"
                        placeholder="name@example.com">
                </div>
                <div class="">
                    <i class="bi fs-5 bi-envelope-fill"></i>
                    <label for="exampleFormControlInput2" class="mt-2 h6  form-label">Contact</label>
                    <input type="number" class="form-control" id="contact" name="contact" autocomplete="new-password"
                        placeholder="Contact Number">
                </div>
                <div class="mb-3">
                    <label for="exampleFormControlTextarea1" class="form-label">Password</label>
                    <input type="password" class="form-control" id="password" name="password" rows="3">
                </div>
                <div class="text-center mb-2">
                    <button type="submit" class="form-control bg-dark text-white">Update</button>
                </div>
            </form>
        </div>
    </div>
</div>

