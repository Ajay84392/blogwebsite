@extends('layout.admin')
@section('content')
<div class="container mt-2">
    <div class="row">
        <div class="col-lg-">
            <div class="table-responsive">
                <table class="table table-white able-hover">
                    <thead>
                        <tr>
                            <th class="h6">ID</th>
                            <th class="h6">FULL NAME</th>
                            <th class="h6">DATE OF BIRTH</th>
                            <th class="h6">EMAIL</th>
                            <th class="h6">CONTACT</th>
                            <th class="h6">EDIT</th>
                            <th class="h6">DELETE</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($data['user'] as $i => $u)
                            <tr>
                                <th>{{ $u->id }}</th>
                                <th>{{ $u->full_name }}</th>
                                <th>{{ $u->dob}}</th>
                                <th>{{ $u->email }}</th>
                                <th>{{ $u->contact}}</th>
                                <th><a href="{{ url('edit', ['id' => $u->id]) }}" class="btn btn-success">Edit</a>
                                </th>
                                <th><a href="{{ url('delete', ['id' => $u->id]) }}" class="btn btn-danger">Delete</a>
                                </th>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
                <div class="d-flex justify-content-center">{{ $data['user']->links() }}</div>
            </div>
        </div>
    </div>
</div>
@endsection
