@extends('layout.default')
@section('content')
<div class="container mt-3">
    <div class="row">
        <div class="col">
            <h5>Welcome to this contact page </h5>
            <p>We’d love to hear from you! Whether you have questions, need assistance, or want to provide feedback, our team is here to help. Please reach out via the form below, or email us directly. For immediate assistance, call us during business hours. We aim to respond to all inquiries within 24 hours. Stay connected by following us on our social media channels for updates, news, and promotions. Your satisfaction is important to us, and we look forward to connecting with you!</p>
           
        </div>
    </div>
</div>
<section class="bg-light py-5" id="contact">
    <div class="container">
        <h2 class="text-center">Contact Us</h2>
        <p class="text-center">Feel free to reach out to us using the form below.</p>
        <div class="row justify-content-center">
            <div class="col-md-6">
                <form method="POST"> 
                    <div class="mb-3">
                        <label for="name" class="form-label">Name</label>
                        <input type="text" class="form-control" id="name" name="name" required>
                    </div>
                    <div class="mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" class="form-control" id="email" name="email" required>
                    </div>
                    <div class="mb-3">
                        <label for="message" class="form-label">Message</label>
                        <textarea class="form-control" id="message" name="message" rows="4" required></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary w-100"><a href="includes.contact"></a> Message</button>
                </form>
            </div>
        </div>
    </div>
</section>
@endsection
@section('css')
@endsection
@section('script')
@endsection
