<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Online Booking</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f9;
        }
        .container {
            max-width: 600px;
            margin: 50px auto;
            padding: 20px;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        h1 {
            text-align: center;
            color: #333;
        }
        form {
            display: flex;
            flex-direction: column;
        }
        label {
            margin-bottom: 5px;
            font-weight: bold;
        }
        input, select, textarea, button {
            margin-bottom: 15px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 16px;
        }
        button {
            background-color: #5cb85c;
            color: white;
            cursor: pointer;
            border: none;
        }
        button:hover {
            background-color: #4cae4c;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Book Your Appointment</h1>
        <form action="/submit-booking" method="POST">
            <label for="name">Full Name</label>
            <input type="text" id="name" name="name" placeholder="Enter your full name" required>
            <label for="email">Email</label>
            <input type="email" id="email" name="email" placeholder="Enter your email" required>
            <label for="phone">Phone Number</label>
            <input type="tel" id="phone" name="phone" placeholder="Enter your phone number" required>
            <label for="date">Select Date</label>
            <input type="date" id="date" name="date" required>
            <label for="time">Select Time</label>
            <input type="time" id="time" name="time" required>
            <label for="service">Select Service</label>
            <select id="service" name="service" required>
                <option value="">-- Choose a service --</option>
                <option value="consultation">Consultation</option>
                <option value="therapy">Therapy</option>
                <option value="checkup">Check-up</option>
            </select>
            <label for="notes">Additional Notes</label>
            <textarea id="notes" name="notes" placeholder="Any additional information"></textarea>
            <button type="submit">Submit Booking</button>
        </form>
    </div>
</body>
</html>
