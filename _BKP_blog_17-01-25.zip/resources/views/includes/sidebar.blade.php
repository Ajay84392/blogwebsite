<div class="bg-black navbar">
    <div class="text-white" style="width:20rem;height:100vh;">
        <div class=" d-flex align-items-center p-">
            <div class="avatar-section d-flex flex-column mx-5 mt-4">
                @if (Helper::isLogged())
                    <div class="">
                        @if (Auth::check() && Auth::user()->avatar)
                            <img src="{{ asset('public/' . Helper::getAvatar()) }}" alt="User Avatar"
                                class="user-avatar rounded-circle border border-white" style="width: 60px; height: 60px;">
                        @else
                            <span>No Image</span>
                        @endif
                        @if (Helper::isLogged())
                            <a class="no-underline mx-3 text-white"
                                href="{{ route('index') }}">{{ Helper::getUserName() }}</a>
                        @endif
                    </div>
                    <a href="#menuSiteSettings" class="nav-link text-white" data-bs-toggle="collapse" role="button"
                        aria-expanded="false" aria-controls="menuSiteSettings">
                        <span class="material-symbols-outlined d-flex justify-content-center">Edit</span>
                    </a>
                    <div class="collapse" id="menuSiteSettings">
                        <form action="{{ route('upload-avatar') }}" method="POST" enctype="multipart/form-data"
                            class="text-center w-85 mt-3" id="avatarForm">
                            @csrf
                            <input type="file" name="avatar" accept="image/*"
                                class="form-control form-control-sm mb-2">
                            <div class="d-flex justify-content-between">
                                <button type="submit" class="btn btn-primary btn-sm" id="uploadButton">Upload
                                    Avatar</button>
                                <a href="{{ route('delete-avatar') }}" class="btn btn-danger btn-sm"
                                    id="deleteButton">Remove Avatar</a>
                            </div>
                        </form>
                    </div>
                @endif
            </div>
        </div>
        <div class="text-white offcanvas-body">
            <div class="blog d-flex align-items-center p-2 mt-2">
                <i class="bi fs-3 me-3 bi-house-fill"></i>
                <a class="nav-link active" href="{{ route('blog-home') }}">Dashboard</a>
            </div>
            <div class="blog d-flex align-items-center p-2 mt-3">
                <i class="bi fs-3 me-3 bi-table"></i>
                <a class="nav-link active" href="{{ route('blog-list') }}">Blog</a>
            </div>
            <div class="blog d-flex align-items-center p-2 mt-3">
                <i class="bi fs-3 me-3 bi-people"></i>
                <a class="nav-link active" href="{{ route('fblog-member') }}">Members</a>
            </div>
            <div class="blog d-flex align-items-center p-2 mt-3">
                <i class="bi fs-3 me-3 bi-card-list"></i>
                <a class="nav-link active" href="{{ route('blog-voucher') }}">Vouchers</a>
            </div>
            <div class="blog d-flex align-items-center p-2 mt-3">
                <i class="bi fs-3 me-3 bi-wifi"></i>
                <a class="nav-link active" href="{{ route('blog-reservation') }}">Reservations</a>
            </div>
            <div class="blog d-flex align-items-center p-2 mt-3">
                <i class="bi fs-3 me-3 bi-bar-chart-fill"></i>
                <a class="nav-link active" href="{{ route('blog-chart') }}">Chart</a>
            </div>
            <div class="blog d-flex align-items-center p-2 mt-3">
                <i class="bi fs-3 me-3 bi-key-fill"></i>
                <a class="nav-link active" href="{{ route('detail') }}">Password Manager</a>
            </div>
            <div class="blog d-flex align-items-center p-2 mt-3">
                <i class="bi fs-3 me-3 bi-power"></i>
                <a class="nav-link active" href="{{ route('login') }}">Login page</a>
            </div>
        </div>
    </div>
</div>
