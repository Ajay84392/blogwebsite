<footer class="color2 text-white text-light py-4">
    <div class="container">
        <div class="row">
            <div class="col-md-3">
                <h5>Product</h5>
                <ul class="list-unstyled">
                    <li><a class="text-white no-underline true" aria-current="page">Website templates</a></li>
                    <li><a class="text-white no-underline true" aria-current="page">Terms of Sale</a></li>
                    <li><a class="text-white no-underline true" aria-current="page">Pivacy Policy</a></li>
                    <li><a class="text-white no-underline true" aria-current="page">Accessibility</a></li>
                </ul>
            </div>
            <div class="col-md-3 ">
                <h5>Solutions</h5>
                <ul class="list-unstyled">
                    <li><a href="{{'store'}}" class="text-white no-underline true" aria-current="page">Online Store</a></li>
                    <li><a href="{{'online'}}" class="text-white no-underline true" aria-current="page">Online Booking </a></li>
                    <li><a class="text-white no-underline true" aria-current="page">Restaurant Website</a></li>
                    <li><a class="text-white no-underline true" aria-current="page">Blog Website</a></li>
                </ul>
            </div>
            <div class="col-md-3">
                <h5>Quick Links</h5>
                <ul class="list-unstyled">
                    <li><a href="{{ 'blog' }}" class="text-white no-underline true" aria-current="page">Blog</a></li>
                    <li><a href="{{'about'}}" class="text-white no-underline true" aria-current="page">About</a></li>
                    <li><a href="{{ 'services' }}" class="text-white no-underline true" aria-current="page">Services</a></li>
                    <li><a href="{{ 'contact' }}" class="text-white no-underline true" aria-current="page">Contact</a></li>
                </ul>
            </div>
            <div class="col-md-3 ">
                <h5>Social Icons</h5>
                <ul class=" mx-5 list-unstyled">
                    <li><a href="https://x.com/"><i class="text-white no-underline true bi bi-twitter-x"></i></a></li>
                    <li><a href="https://www.facebook.com/"><i class="text-white no-underline true bi bi-facebook"></i></li>
                    <li><a href="https://www.youtube.com/"><i class="text-white no-underline true bi bi-youtube"></i></li>
                    <li><a href="https://www.instagram.com/"><i class="text-white no-underline true bi bi-instagram"></i></li>
                </ul>
            </div>
        </div>
    </div>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js?<?php echo time(); ?>"
    integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+" crossorigin="anonymous">
</script>
<style>
    .color2 {
        background-color: #124DAC;
    }
</style>
