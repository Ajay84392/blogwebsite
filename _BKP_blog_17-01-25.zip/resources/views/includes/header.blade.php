<nav class="navbar navbar-expand-md navbar-dark nav">
    <div class="container ">
        <div class="navbar-collapse justify-content-end">
            <ul class="navbar-nav  ">
                <li class="nav-link">
                    <form class="d-flex " role="search">
                        <input class=" form-control  me-1" type=" search" placeholder="Search" aria-label="Search">
                    </form>
                </li>
                <li class="nav">
                    <i class="bi mx-2 mt-2 text-white fs-4 bi-house-door-fill"></i>
                    <a class="nav text-white mt-3 " aria-current="page" href="{{ route('index') }}">Home</a>
                </li>
                <li class="nav mx-2">
                    <i class="bi text-white fs-3 mx-1 mt-2 bi-caret-down-fill"></i>
                    <a class="nav text-white mt-3" aria-current="page" href="{{ route('blog') }}">Blog</a>
                </li>
                <li class="nav mx-2">
                    <i class="bi text-white fs-3 mx-1 mt-2 bi-caret-down-fill"></i>
                    <a class="nav text-white mt-3" aria-current="page" href="{{ route('crud') }}">Test</a>
                </li>
                <li class="nav mx-2">
                    <i class="bi text-white fs-3 mx-1 mt-2 bi-caret-down-fill"></i>
                    <a class="nav text-white mt-3" aria-current="page" href="{{ route('information') }}">Product</a>
                </li>
                {{-- @if (Helper::isLogged())
                    <li class="nav-link">
                        <i class="bi text-white fs-3 mx-1 mt-2 bi-caret-down-fill"></i>
                        <a class="nav-link active mt-1" aria-current="page" href="{{ route('logout') }}">Logout</a>
                    </li>
                @else
                    <li class="nav mx-2">
                        <i class="bi text-white fs-3 mx-1 mt-2 bi-caret-down-fill"></i>
                        <a class="nav text-white mt-3" aria-current="page" href="{{ route('login') }}">Login</a>
                    </li>
                @endif --}}
                <div class="dropdown">
                    <button class="btn bt-info mt-1" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <ul class="dropdown-menu">
                        @if (Helper::isLogged())
                            <li><a class="dropdown-item" href="{{ route('blog-home') }}">Dashboard</a></li>
                            <li><a class="dropdown-item" aria-current="page" href="{{ route('crud') }}">student
                                    Login</a>
                            <li><a class="dropdown-item" aria-current="page" href="{{ route('customer') }}">Customer
                                    Login</a>
                            </li>
                            <li>
                                <a class="dropdown-item" href="{{ route('logout') }}">Log Out</a>
                            </li>
                        @else
                            <li>
                                <a class="dropdown-item" href="{{ route('login') }}">Log In</a>
                            </li>
                        @endif
                    </ul>
                </div>
            </ul>
        </div>
    </div>
</nav>
