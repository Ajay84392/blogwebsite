{{-- <div class="alert alert-success alert-dismissible">
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    <strong>Thank You!</strong> Your Registration Detail is successfully Submitted.
</div>    --}}

@extends('layout.default')
@section('content')
    <p>huj</p>
    <img src="{{ asset('public/image/abc6.webp') }}" class="d-block mb-4" alt="..." style="height: 400px; width: 100%;">
@endsection
