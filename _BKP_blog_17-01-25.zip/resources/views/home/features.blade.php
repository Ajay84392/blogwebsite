{{-- @extends('layout.default') --}}
{{-- @section('content') --}}
<section id="main-page-nav-bar">
    <nav class="navbar bg-primary navbar-expand-sm" style="height:67px;">
        <div class="mx-3 navbar-collapse">
            <div class="col-md-8 col-md-6">
                <a href="{{ 'pricing' }}"></a>
                <p class="h5 mx-auto mb-0 d-flex align-items-center gap-5 text-white">
                    <a href="{{ 'pricing' }}" class="nav-link" aria-current="page"><i
                            class="bi fs-4 bi-arrow-left"></i></a>
                    General purpose programming in a variety of languages
                </p>
            </div>
            <div class="col-md-4 text-end">
                <i class="bi mx-1 text-warning h3 bi-star-fill"></i>
                <i class="bi mx-1 text-warning h3 bi-star-fill"></i>
                <i class="bi mx-1 text-warning h3 bi-star-fill"></i>
                <i class="bi mx-1 text-warning h3 bi-star-fill"></i>
                <i class="bi mx-1 text-warning h3 bi-star-fill"></i>
            </div>
        </div>
    </nav>
</section>
<section id="main-page-nav-bar">
    <nav class="navbar bg-white navbar-expand-sm">
        <div class="col-md-9 ">
            <ul class="list-group list-group-horizontal">
                <li class="list-group-item">
                    <a href="" class="btn btn-secondary">Sections</a>
                </li>
                <li class="list-group-item">
                    <a href="" class="btn btn-light">Coading</a>
                </li>
                <li class="list-group-item">
                    <a href="" class="btn btn-light">Data Science</a>
                </li>
                <li class="list-group-item">
                    <a href="" class="btn btn-light">Multiple Choice</a>
                </li>
                <li class="list-group-item">
                    <a href="" class="btn btn-light">Book</a>
                </li>
                <li class="list-group-item">
                    <a href="" class="btn btn-light">Library Genesis</a>
                </li>

            </ul>

            <div class="row mt-3">
                <div class="col-md-8 d-flex justify-content-start mx-5">
                    <p class="mx-3 h5" id="q-title">Question No.1</p>
                    <button type="incorrect" class="btn h5 btn-danger" style="border-radius:25px;">incorrect</button>
                    <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor"
                        class="bi bi-alarm-fill mx-2" viewBox="0 0 16 16">
                        <path
                            d="M6 .5a.5.5 0 0 1 .5-.5h3a.5.5 0 0 1 0 1H9v1.07a7.001 7.001 0 0 1 3.274 12.474l.601.602a.5.5 0 0 1-.707.708l-.746-.746A6.97 6.97 0 0 1 8 16a6.97 6.97 0 0 1-3.422-.892l-.746.746a.5.5 0 0 1-.707-.708l.602-.602A7.001 7.001 0 0 1 7 2.07V1h-.5A.5.5 0 0 1 6 .5m2.5 5a.5.5 0 0 0-1 0v3.362l-1.429 2.38a.5.5 0 1 0 .858.515l1.5-2.5A.5.5 0 0 0 8.5 9zM.86 5.387A2.5 2.5 0 1 1 4.387 1.86 8.04 8.04 0 0 0 .86 5.387M11.613 1.86a2.5 2.5 0 1 1 3.527 3.527 8.04 8.04 0 0 0-3.527-3.527" />
                    </svg>
                    <p class="h5">You: 00:10 Avg: 00:08</p>
                    <button type="incorrect" class="btn mx-2 h5 btn-success"
                        style="border-radius:25px;">correct</button>
                </div>
            </div>
            <div class="row  mx-5">
                <div class="col">
                    <p class="mx-3" id="question"> Who is president of india ?­</p>
                    <div class="form-check ">
                        <label class="form-check-label " for="option-1" id="options">
                            
                        </label>
                    </div>
                    <div class="card bg-primary-subtle mt-4" style="width: 40rem;height:215px;">
                        <div class="card-body">
                            <button type="incorrect" class="btn mt-3 h6 btn-primary">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                                    fill="currentColor" class="bi mx-2 bi-eye" viewBox="0 0 16 16">
                                    <path
                                        d="M16 8s-3-5.5-8-5.5S0 8 0 8s3 5.5 8 5.5S16 8 16 8M1.173 8a13 13 0 0 1 1.66-2.043C4.12 4.668 5.88 3.5 8 3.5s3.879 1.168 5.168 2.457A13 13 0 0 1 14.828 8q-.086.13-.195.288c-.335.48-.83 1.12-1.465 1.755C11.879 11.332 10.119 12.5 8 12.5s-3.879-1.168-5.168-2.457A13 13 0 0 1 1.172 8z" />
                                    <path
                                        d="M8 5.5a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5M4.5 8a3.5 3.5 0 1 1 7 0 3.5 3.5 0 0 1-7 0" />
                                </svg>
                                solution</button>
                            <p class="card-text mt-3">Some quick example text to build on the card title and make up the
                                bulk
                                of the card's content.</p>
                            <h6>Correct Answer:</h6>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </nav>
    <nav class="navbar bg-primary-subtle navbar-expand mt-5" style="height:68px;">
        <div class="mx-3 navbar-collapse d-flex align-items-center">
            <button type="button" id="prevButton" class="btn btn-secondary">Previous</button>
            <p class="mx-auto mb-0 d-flex align-items-center me-2">
                Re-attempt Questions
            <div class="col-lg-5">
                <div class="form-check form-switch">
                    <input class="form-check-input bg-primary" type="checkbox" role="switch"
                        id="flexSwitchCheckChecked" checked style="height: 25px;width: 70px;">
                </div>
            </div>
            </p>
            <button type="button" id="nextButton" class="btn btn-secondary ms-3">Next</button>
        </div>
    </nav>
</section>
{{-- @endsection --}}
@section('css')
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://code.jquery.com/ui/1.13.2/jquery-ui.js"
        integrity="sha256-xLD7nhI62fcsEZK2/v8LsBcb4lG7dgULkuXoXB/j91c=" crossorigin="anonymous"></script>
@endsection
@section('script')
    <script>
        // box right 
        function slideRight() {
            var effect = 'slide';
            var options = {
                direction: "right"
            };
            var duration = 300;
            $('#myDiv2').toggle(effect, options, duration);
        }
        // end box right
    </script>
@endsection



{{-- start 12 --}}
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
<link rel="stylesheet" href="{{ asset('./public/template/frontend_css.css') }}">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
@yield('css')
<main>
    @yield('content')
</main>
@yield('script')
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"
    integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous">
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js"
    integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+" crossorigin="anonymous">
</script>
{{-- end 12 --}}

{{-- start end nav --}}
<script>
    document.getElementById('prevButton').addEventListener('click', function() {
        alert('Please Attempt the questions!');
    });
</script>
{{-- end end-nav --}}


<script>
    // Questions Array
    const questions = [{
            title: "Question No.1",
            question: "Who is the president of India?",
            options: [
                "Jayshanker",
                "Narendra Modi",
                "Rajnath Singh",
                "Droupadi Murmu"
            ],
            correct: 3 // Index of the correct answer
        },
        {
            title: "Question No.2",
            question: "What is the capital of France?",
            options: [
                "Berlin",
                "Madrid",
                "Paris",
                "Lisbon"
            ],
            correct: 2
        },
        {
            title: "Question No.3",
            question: "Which planet is known as the Red Planet?",
            options: [
                "Earth",
                "Mars",
                "Jupiter",
                "Saturn"
            ],
            correct: 1 // Index of the correct answer
        },
        {
            title: "Question No.4",
            question: "What is the square root of 16?",
            options: [
                "2",
                "4",
                "6",
                "8"
            ],
            correct: 1 // Index of the correct answer
        },
        {
            title: "Question No.5",
            question: "What is the square root of 25?",
            options: [
                "5",
                "4",
                "6",
                "8"
            ],
            correct: 1 // Index of the correct answer
        },
        {
            title: "Question No.6",
            question: "What is the square root of 36?",
            options: [
                "6",
                "4",
                "6",
                "8"
            ],
            correct: 1 // Index of the correct answer
        },
        {
            title: "Question No.7",
            question: "What is the square root of 49?",
            options: [
                "7",
                "4",
                "6",
                "8"
            ],
            correct: 1 // Index of the correct answer
        },
        {
            title: "Question No.8",
            question: "What is the square root of 64?",
            options: [
                "8",
                "4",
                "6",
                "8"
            ],
            correct: 1 // Index of the correct answer
        },
        {
            title: "Question No.9",
            question: "What is the square root of 81?",
            options: [
                "9",
                "4",
                "6",
                "8"
            ],
            correct: 1 // Index of the correct answer
        },
        {
            title: "Question No.10",
            question: "What is the square root of 100?",
            options: [
                "2",
                "4",
                "6",
                "10"
            ],
            correct: 4 // Index of the correct answer
        }
    ];

    let currentQuestionIndex = 0;

    // Render the current question
    function renderQuestion() {
        const currentQuestion = questions[currentQuestionIndex];
        document.getElementById("q-title").textContent = currentQuestion.title;
        document.getElementById("question").textContent = currentQuestion.question;
        document.getElementById("options").textContent = currentQuestion.options;

        function updateOptions(questionIndex, newOptions, correctIndex) {
            if (questions[questionIndex]) {
                questions[questionIndex].options = newOptions;
                questions[questionIndex].correct = correctIndex;
            } else {
                console.error("Question index out of range.");
            }
        }
        const optionsContainer = document.getElementById("options");
        optionsContainer.innerHTML = ""; // Clear existing options
        currentQuestion.options.forEach((option, index) => {
            const optionElement = `
                <div class="form-check tab">
                     <input class="form-check-input" type="radio" name="question" id="option-${index}" value="${index}">
                    <label class="form-check-label" for="option-${index}">
                        ${option}
                    </label>
                </div>
            `;
            optionsContainer.innerHTML += optionElement;
        });
    }


    // Handle Next button click
    document.getElementById('nextButton').addEventListener('click', function() {
        if (currentQuestionIndex < questions.length - 1) {
            currentQuestionIndex++;
            renderQuestion();
        } else {
            alert("This is the last question!");
        }
    });

    // Example of dynamically updating options
    // Update Question No.2 options

    // Initial render
    renderQuestion();
</script>
