@extends('layout.default')
@section('content')
    <div class="container">
        <div class="row">
            <div class="card my-2" style="width: 40%;margin-left:auto; margin-right:auto;">
                <p class="h2 p-5 text-center">Multiform <span><a href="{{url('application/detail')}}" class="btn btn-secondary">Application Detail</a></span></p>
                
                <form action="{{ URL::current() }}" method="post">
                    @csrf
                    <div class="col mt-2">
                        <div class="mb-3">
                            <label for="title" class="form-label">Title</label>
                            <input type="text" class="form-control" id="title" name="title"
                                placeholder="Enter title">
                        </div>
                    </div>
                    <div class="col">
                        <div class="mb-3">
                            <label for="input_id" class="form-label">Input id</label>
                            <input type="text" class="form-control" id="input_id" name="input_id"
                                placeholder="input id">
                        </div>
                    </div>
                    <div class="col">
                        <div class="mb-3">
                            <label for="input_name" class="form-label">Input Name</label>
                            <input type="text" class="form-control" id="input_name" name="input_name"
                                placeholder="input name">
                        </div>
                    </div>
                    <div class="col mt-2">
                        <div class="mb-3">
                            <label for="type" class="form-label">Type</label>
                            <input type="text" class="form-control" id="type" name="type"
                                placeholder="Enter Text">
                        </div>
                    </div>
                    <div class="col">
                        <div class="mb-3">
                            <label for="site_location" class="form-label">Site Location</label>
                            <input type="text" class="form-control" id="site_location" name="site_location"
                                placeholder="site location">
                        </div>
                    </div>
                    <div class="col">
                        <div class="mb-3">
                            <label for="exampleFormControlInput1" class="form-label">Status</label>
                            <select name="status" id="status" class="form-control">
                                <option value="active" selected> Active</option>
                                <option value="inactive"> Inactive</option>
                            </select>
                        </div>
                    </div>

                    <div class="col">
                        <div class="mb-3">
                            <button class="btn btn-info" type="submit"> Submit</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        </div>
    @endsection
    @section('css')
        <style>
            .start-css {}
        </style>
    @endsection
    @section('script')
    @endsection
