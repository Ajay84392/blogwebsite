@extends('layout.default')
@section('content')
    <div class="container mt-4 mb-4">
        <h5>INSTRUCTIONS TO THE STUDENTS FOR EXAMINATIONS</h5>
        <p>1. Please occupy your (appropriate/ allotted) seat in the examination hall at least ten minutes
            before the start of the examination and do not forget to bring your Identity Card.</p>

        <p>2. Please carry all the required and authorized items including pens, pencils, erasers, rulers
            where appropriate non-programmable calculators and drawing instruments in to the
            examination hall.</p>

        <p>3. Only pens with blue/ black/ blue-black color ink should be used for writing unless the
            question paper gives other instructions. </p>

        <p>4. During the examination, possession of unauthorized materials, improper use of materials,
            misconduct, discussing, cheating, adoption of unfair means, impersonation and
            unauthorized removal of material from examination halls or ignoring the instructions
            given by the invigilators leads to academic disciplinary action. However, if the
            examination is open book/ open notes, students are allowed to keep only the material
            approved by the instructor.</p>

        <p>5. During the examination, a student can take temporary break to wash room, with the
            permission of the invigilator. During such break, adopting any unfair means (even talking
            to other students) outside the examination hall leads to academic disciplinary action.</p>

        <p>6. All answer sheets including sheets/pages used for rough work must be tied and handed
            over to the invigilator at the end of examination.</p>

        <p>7. Violating in any form leads to academic disciplinary action.</p>

        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
            Start Your Test
        </button>
    </div>

    <body>
        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content" style="width: 60rem;">
                    <p class="h4">Select Question Type</p>
                    <div class="row">
                        <div class="col mt-4">
                            <p>Programming</p>
                            <p class="text-secondary">Recommended for junior developers</p>
                            <div class=" card-p">
                                <a href="{{ 'features' }}">Coding<br>General purpose programming in a variety
                                    of languages</a>
                            </div>
                        </div>
                        <div class="col mt-4">
                            <p>Projects</p>
                            <p class="text-secondary">Container-based real-world challenges</p>
                            <div class=" card-p">
                                <a href="{{ 'features' }}">Data Science<br>Access skills like data wrangling,
                                    visualization, ML, etc.,
                                    through Jupyter Notebooks</a>
                            </div>
                        </div>
                        <div class="col mt-4">
                            <p>General</p>
                            <p class="text-secondary">Based on coding</p>
                            <div class=" card-p">
                                <a href="{{ 'features' }}">Multiple Choice<br>Single or multiple correct
                                    answers</a>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col mt-4">

                            <div class=" card-p">
                                <a href="{{ 'features' }}">HTML/CSS/JavaScript<br>Simple programming using HTML, CSS, and
                                    JavaScript</a>
                            </div>
                        </div>
                        <div class="col mt-4">

                            <div class=" card-p">
                                <a href="{{ 'features' }}">Book</a>
                            </div>
                        </div>
                        <div class="col mt-4">

                            <div class=" card-p">
                                <a href="{{ 'features' }}">Library Genesis </a>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col">
                            <div class=" card-p">
                                <a href="{{ 'features' }}">Databases<br>SQL programming across databases</a>
                            </div>
                        </div>
                        <div class="col">
                            <div class=" card-p">
                                <a href="{{ 'features' }}">Back-end Developer<br>Support for multiple languages and
                                    frameworks</a>
                            </div>
                        </div>
                        <div class="col">
                            <div class=" card-p">
                                <a href="{{ 'features' }}">Whiteboard<br>Basic shapes and text</a>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col">
                            <div class=" card-p">
                                <a href="{{ 'features' }}">Approximate Solution</a>
                            </div>
                        </div>
                        <div class="col">
                            <div class=" card-p">
                                <a href="{{ 'features' }}">Full-stack Developer</a>
                            </div>
                        </div>
                        <div class="col">
                            <div class=" card-p">
                                <a href="{{ 'features' }}">Diagram</a>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col">
                            <div class=" card-p">
                                <a href="{{ 'features' }}">Front-end Developer<br>Support for React, Angular, and other
                                    frameworks</a>
                            </div>
                        </div>
                        <div class="col">
                            <div class=" card-p">
                                <a href="{{ 'features' }}">Subjective<br>Free-text answers</a>
                            </div>
                        </div>
                        <div class="col">
                            <div class=" card-p">
                                <a href="{{ 'features' }}">Controller</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>
@endsection
@section('css')
    <style>
        .start-css {}

        a {
            text-decoration: none;
            color: black;
        }
    </style>
@endsection
@section('script')
@endsection
