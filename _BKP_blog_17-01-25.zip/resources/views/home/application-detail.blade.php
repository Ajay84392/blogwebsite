@extends('layout.default')
@section('content')
    <div class="container">
        <div class="row">
            <div class="col">
                <p class="h2 text-center mt-5">Multiple form Table </p>
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr class="h5">
                                <th scope="col">Sno</th>
                                <th scope="col">Title</th>
                                <th scope="col">Input Id</th>
                                <th scope="col">Input Name</th>
                                <th scope="col">Type</th>
                                <th scope="col">Site Location</th>
                                <th scope="col">Status</th>
                                <th scope="col">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($data['input'] as $f)
                                <tr class="">
                                    <td scope="row">{{ $f->id }}</td>
                                    <td>{{ $f->title }}</td>
                                    <td>{{ $f->input_id }}</td>
                                    <td>{{ $f->input_name }}</td>
                                    <td>{{ $f->type }}</td>
                                    <td>{{ $f->site_location }}</td>
                                    <td>{{ $f->status }}</td>
                                    <td><a href="{{ url('application/edit') }}" class="btn btn-success"><i class="bi bi-pencil-square"></i></a>
                                        <a href="{{ url('application/delete') }}" class="btn btn-danger"><i class="bi bi-trash3"></i></a>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <hr class="mt-5">

        {{-- test for multiple forms --}}
        <div class="row">
            @foreach ($data['multi'] as $d)
                <form action="" method="post">
                    <div class="col-lg-4">
                        <div class="mb-3">
                            <label for="{{$d->input_id}}" class="form-label">{{$d->title}}</label>
                            <input type="{{$d->type}}" class="form-control" id="{{$d->input_id}}" name="{{$d->input_name}}" placeholder="">
                        </div>
                    </div>
                </form>
            @endforeach
        </div>
        {{-- end of test for multiple forms --}}
    </div>
@endsection
@section('css')
    <style>
        .start-css {}
    </style>
@endsection
@section('script')
@endsection
