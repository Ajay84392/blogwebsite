@extends('layout.default')
@section('content')
    <div class="container mt-3 d-flex">
        <img src="{{ asset('public/image/abc4.jpg') }}" class="d-block" alt="..." style="height:100px;width:10rem;">
        <h5 class="mt-3">GOOD DAY</h5>
        <div class="mx-2" style="border-right: 2px solid">
        </div>
        <div>
            <div class="h5 mt-3 text-secondary">START YOUR BLOG WEBSITE</div>
            <div class="mt-2 h5 uppercase">APPLICATION PREVIEW GUIDE - HOW TO MAKE USERS DOWNLOAD YOUR APP </div>
        </div>
    </div>
    <div class="container">
        <div id="carouselExampleInterval" class="carousel slide" data-bs-ride="carousel">
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <section class="container" id="image">
                        <div class="col-12 my-3">
                            <div class="card text-bg-dark" style="height:350px;position:relative;">
                                <img src="{{ asset('public/image/abc.jpg') }}" class="d-block" alt="..."
                                    style="height: 400px; width: 100%;">
                                <div class="card-img-overlay d-flex flex-column justify-content-center">
                                    <h3 class="card-title">Download App</h3>
                                    <h3 p class="card-text">This is a wider card with supporting text below as a
                                        natural
                                        lead-in to his is a wider card with supporting text below as a natural
                                    </h3 p>
                                </div>
                            </div>
                        </div>
                    </section>
                </div>
                <div class="carousel-item" data-bs-interval="2000">
                    <section class="container" id="image">
                        <div class="row">
                            <div class="col-12 my-3">
                                <div class="card text-bg-dark" style="height:350px;position:relative;">
                                    <img src="{{ asset('public/image/abc2.jpg') }}" class="d-block" alt="..."
                                        style="height: 400px; width: 100%;">
                                    <div class="card-img-overlay text-center d-flex flex-column justify-content-center">
                                        <h3 p class="card-text">This is a long paragraph written to show how the
                                            line-height
                                            of an element is affected by our utilities. Classes are applied to the
                                            element
                                            itself or sometimes the parent element.</h3 p>
                                    </div>
                                </div>
                            </div>
                    </section>
                </div>
                <div class="carousel-item">
                    <section class="container" id="image">
                        <div class="row">
                            <div class="col-12 my-3">
                                <div class="card text-bg-dark" style="height:350px;position:relative;">
                                    <img src="{{ asset('public/image/abc3.jpeg') }}" class="d-block" alt="..."
                                        style="height: 400px; width: 100%;">
                                    <div class="card-img-overlay text-end d-flex flex-column justify-content-center">
                                        <h3 p class="card-text">Classes are applied to the element itself or sometimes
                                            the
                                            parent element.These classes can be customized as needed with our
                                            utility API.
                                        </h3 p>
                                    </div>
                                </div>
                            </div>
                    </section>
                </div>
            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleInterval"
                data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleInterval"
                data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
            </button>
        </div>
    </div>
    <div class="car text-white ">
        <marquee class="mt-2">This is a long paragraph written to show how the
            line-height of an element is affected by our utilities.
            Classes are applied to the element itself or sometimes the parent element.
        </marquee>
    </div>
    <section>
        <div class="container mt-3">
            <div class="row">
                <div class="col">
                    <h2>description</h2>
                    <p class="h-1">This is a long paragraph written to show how the line-height of an element is
                        affected by
                        our
                        utilities. Classes are applied to the element itself or sometimes the parent element. These
                        classes can
                        be
                        customized as needed with our utility API This is a long paragraph written to show how the
                        line-height
                        of an
                        element is affected by our utilities. Classes are applied to the element itself or sometimes the
                        parent
                        element.
                        These classes can be customized as needed with our utility API.
                        This is a long paragraph written to show how the line-height of an element is affected by our
                        utilities.
                        Classes
                        are applied to the element itself or sometimes the parent element. These classes can be
                        customized as
                        needed
                        with our utility API.</p>
                </div>
            </div>
        </div>
        <section id="block-block-21" class="block block-block clearfix">
            <section class="dashboard-reporting">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12 mar-top-20 center-position">
                            <h2>Project related service</h2>
                            <p>The purpose of this project proposal is to address the critical need for strengthening social
                                services in underserved communities. The project aims to create a comprehensive approach
                                that enhances the availability, accessibility, and quality of essential social services for
                                vulnerable populations. By collaborating with local stakeholders and implementing
                                evidence-based strategies, we aim to empower communities and foster sustainable positive
                                change.In societies around the world, the strength and resilience of a community are often
                                measured by its ability to care for its most vulnerable members. However, certain
                                communities face significant challenges in accessing essential social services that can
                                enhance their well-being and uplift their quality of life.</p>
                        </div>
                    </div>
                </div>
                <div class="container d-flex">
                    @if (!empty($data['page']))
                        <div class="mx-">
                            <div class="row g-0 border rounded overflow-hidden flex-md-row mb-4 shadow-sm h-md-250 position-relative"
                                style="width:24rem;">
                                <div class="col-auto d-none d-lg-block">
                                    <div class="col-auto d-none d-lg-block">
                                        <img src="{{ asset('public/upload/blog/' . $data['page']->image) }}"
                                            class="d-block img-circle" alt="{{ $data['page']['title'] ?? 'Blog Image' }}"
                                            style="height:200px; width:200px; border-radius: 50%; object-fit: cover;">
                                    </div>
                                </div>
                                <div class="col p-4 d-flex flex-column position-static">
                                    <strong class="d-inline-block mb-2 text-primary-emphasis">World</strong>
                                    @if (isset($data['page']['title']))
                                        <h3 class="mb-0">{{ $data['page']['title'] }}</h3>
                                    @else
                                        <h3 class="mb-0">No Title found</h3>
                                    @endif
                                    <div class="mb-1 text-body-secondary">Nov 12</div>
                                    <p class="card-text mb-auto">{{ $data['page']['description'] }}</p>
                                </div>
                            </div>
                        </div>
                    @endif
                    @if (!empty($data['page1']))
                        <div class="container  mx-5 col-md-">
                            <div class="row g-0 border rounded overflow-hidden flex-md-row mb-4 shadow-sm h-md-250 position-relative"
                                style="width:24rem;">
                                <div class="col-auto d-none d-lg-block">
                                    <div class="col-auto d-none d-lg-block">
                                        <img src="{{ asset('public/upload/blog/' . $data['page1']->image) }}"
                                            class="d-block img-circle" alt="{{ $data['page1']['title'] ?? 'Blog Image' }}"
                                            style="height:200px; width:200px; border-radius: 50%; object-fit: cover;">
                                    </div>
                                </div>
                                <div class="col p-4 d-flex flex-column position-static">
                                    <strong class="d-inline-block mb-2 text-primary-emphasis">World</strong>
                                    @if (isset($data['page1']['title']))
                                        <h3 class="mb-0">{{ $data['page1']['title'] }}</h3>
                                    @else
                                        <h3 class="mb-0">No Title found</h3>
                                    @endif
                                    <div class="mb-1 text-body-secondary">Nov 12</div>
                                    <p class="card-text mb-auto">{{ $data['page1']['description'] }}</p>
                                </div>
                            </div>
                        </div>
                    @endif
                    @if (!empty($data['page2']))
                        <div class="container mx- col-md-">
                            <div class="row g-0 border rounded overflow-hidden flex-md-row mb-4 shadow-sm h-md-250 position-relative"
                                style="width:24rem;">
                                <div class="col-auto d-none d-lg-block">
                                    <img src="{{ asset('public/upload/blog/' . $data['page2']->image) }}"
                                        class="d-block img-circle" alt="{{ $data['page2']['title'] ?? 'Blog Image' }}"
                                        style="height:200px; width:200px; border-radius: 50%; object-fit: cover;">
                                </div>
                                <div class="col p-4 d-flex flex-column position-static">
                                    <strong class="d-inline-block mb-2 text-primary-emphasis">World</strong>
                                    @if (isset($data['page2']['title']))
                                        <h3 class="mb-0">{{ $data['page2']['title'] }}</h3>
                                    @else
                                        <h3 class="mb-0">No Title found</h3>
                                    @endif
                                    <div class="mb-1 text-body-secondary">Nov 12</div>
                                    <p class="card-text mb-auto">{{ $data['page2']['description'] }}</p>
                                </div>
                            </div>
                        </div>
                    @endif
                </div>
            </section>
        </section>
        <div class="container">
            <hr class="featurette-divider">
            <div class="row featurette container">
                <div class="col-md-6">
                    <h2 class="featurette-heading fw-normal h1">First featurette heading. <span
                            class="text-body-secondary">It’ll blow your mind.</span></h2>
                    <p class="lead mt-3">Some great placeholder content for the first featurette here. Imagine
                        some exciting prose here.</p>
                    <p class="lead">Source from over 800K ready-to-sell products and thousands of product categories.</p>
                    <p class="lead">Maximize profits with complete customization over product pricing and markup.</p>
                </div>
                <div class="col-md-6">
                    <img src="{{ asset('public/image/abc3.jpeg') }}" class="d-block" alt="..."
                        style="height:500px;width:756px;">
                </div>
            </div>
        </div>
        <div class="d-flex mt-5">
            <img src="{{ asset('public/image/abc2.jpg') }}" class="d-block" alt="..."
                style="height:500px;width:753px;">
            <div class="col-md-6 p-5">
                <h2 class="featurette-heading fw-normal">Oh yeah, it’s that good. <span class="text-body-secondary">See
                        for yourself.</span></h2>
                <p class="lead mt-3">Another featurette? Of course. More placeholder content here to give you
                    an idea of how this layout would work with some actual real-world content in place.</p>
                <p class="lead">Choose from 100s of trending items, including premium apparel, accessories and
                    homeware.
                </p>
                <p class="lead">Access leading print on demand apps and customize designs with complete control.</p>
                <p class="lead">Promote your business and increase revenue with custom branded merchandise.</p>
            </div>
        </div>
        <div class="container">
            <div class="row mt-5">
                <div class="col-md-6">
                    <h2 class="featurette-heading fw-normal lh-1">And lastly, this one. <span
                            class="text-body-secondary">Checkmate.</span></h2>
                    <p class="lead">And yes, this is the last block of representative placeholder content.
                        Again, not really intended to be actually read, simply here to give you a better view of
                        what this would look like with some actual content. Your content.</p>
                </div>
                <div class="col-md-6">
                    <img src="{{ asset('public/image/abc1.jpg') }}" class="d-block" alt="..."
                        style="height:500px;width:744px;">
                </div>
            </div>
        </div>
        <script src="/docs/5.3/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous">
        </script>
        <section id="block-block-23" class="block block-block clearfix">
            <section class="public-media">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12 center-position mar-top-20">
                            <h2>Public Media</h2>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12 left-position">
                            <p>These underserved communities, often marginalized and neglected, are at risk of being further
                                left behind in the face of rapid social and economic changes. As we strive for a more
                                inclusive and equitable society, it becomes imperative to focus our efforts on strengthening
                                social services in these marginalized areas.

                                Strengthening social services in underserved communities is not just an act of benevolence;
                                it is a fundamental duty of any just and compassionate society. The term “social services”
                                encompasses a wide range of critical support systems, including access to quality
                                healthcare, education, housing, food security, mental health services, and assistance for
                                vulnerable populations such as children, the elderly, and individuals with disabilities.In
                                this discourse, we will explore the pressing need to prioritize and expand social services
                                in underserved communities. By doing so, we aim to shed light on successful case studies,
                                innovative approaches, and the profound impact that investing in social services can have on
                                fostering inclusive growth, empowering individuals, and strengthening the fabric of society
                                as a whole.

                                In conclusion, a society’s true progress is measured not only by its material gains but by
                                the way it uplifts and supports its most vulnerable members. By placing a spotlight on
                                strengthening social services in underserved communities, we embark on a journey towards a
                                fairer and more compassionate world, where no one is left behind, and where the collective
                                well-being of all is nurtured and celebrated.</p>
                        </div>
                    </div>
                </div>
                </div>
                <div class="container">
                    <div class="col-md-12 left-position">
                        <p class="h2">Feature Title</p>
                        <p>These underserved communities, often marginalized and neglected, are at risk of being further
                            left behind in the face of rapid social and economic changes. As we strive for a more
                            inclusive and equitable society, it becomes imperative to focus our efforts on strengthening
                            social services in these marginalized areas.

                            Strengthening social services in underserved communities is not just an act of benevolence;
                            it is a fundamental duty of any just and compassionate society. The term “social services”
                            encompasses a wide range of critical support systems, including access to quality
                            healthcare, education, housing, food security, mental health services, and assistance for
                            vulnerable populations such as children, the elderly, and individuals with disabilities.In
                            this discourse, we will explore the pressing need to prioritize and expand social services
                            in underserved communities. By doing so, we aim to shed light on successful case studies,
                            innovative approaches, and the profound impact that investing in social services can have on
                            fostering inclusive growth, empowering individuals, and strengthening the fabric of society
                            as a whole.

                            In conclusion, a society’s true progress is measured not only by its material gains but by
                            the way it uplifts and supports its most vulnerable members. By placing a spotlight on
                            strengthening social services in underserved communities, we embark on a journey towards a
                            fairer and more compassionate world, where no one is left behind, and where the collective
                            well-being of all is nurtured and celebrated.</p>
                    </div>
                </div>
            </section>
        </section>
        <div role="region">
            <div class="region region-content-blog-bottom">
                <section id="block-block-20" class="block block-block clearfix">
                    <section class="informational-services">
                        <div class="container">
                            <div class="col-md-12 h5 center-position mar-top-20">
                                <h2>Blogging tips for beginners</h2>
                                <p class="text-primary mt-3">1. Choose a blog niche </p>
                                <p class="text-primary">2. Research your audience </p>
                                <p class="text-primary">3. Draw inspiration online </p>
                                <p class="text-primary">4. Learn what people are searching for </p>
                                <p class="text-primary">5. Use keywords strategically </p>
                                <p class="text-primary">6. Structure your blog by category </p>
                                <p class="text-primary">7. Create an editorial calendar </p>
                                <p class="text-primary">8. Start with an outline </p>
                                <p class="text-primary">9. Use data and research </p>
                                <p class="text-primary">10. Write powerful copy </p>
                                <p class="text-primary">11. Incorporate different content types </p>
                                <p class="text-primary">12. Use a variety of visuals </p>
                                <p class="text-primary">13. Include clickable CTAs </p>
                                <p class="text-primary">14. Develop a powerful linking strategy </p>
                                <p class="text-primary">15. Prioritize long blog posts </p>
                                <p class="text-primary">16. Create a blog newsletter </p>
                                <p class="text-primary">17. Promote your blog on social media </p>
                                <p class="text-primary">18. Expand your online presence </p>
                                <p class="text-primary">19. Monitor your blog analytics </p>
                                <p class="text-primary">20. Take advantage of monetization opportunities </p>
                                <p class="text-primary">21. Keep your content up-to-date </p>
                            </div>
                            <p class="h1 mt-3">Webinars & Events</p>
                            <div class="d-flex container mt-3">
                                <div class="">
                                    <div class="col-md-4">
                                        <img src="{{ asset('public/image/abc15.jpeg') }}" class="d-block" alt="..."
                                            style="height:300px;width:400px;">
                                    </div>
                                    <div class="card-body">
                                        <h5 class="card-title mt-3">Build a Business That Will Sell: From Valuations to a
                                            Successful Exit</h5>
                                        <p class="mt-2 text-primary">Tue, Jan 21, 12:00 EST</p>
                                        <p class="card-text">Join us for this free webinar and learn how to develop a
                                            business that buyers will find irresistible.</p>
                                        <a href="{{route('form')}}" class="btn btn-warning">Reister Now</a>
                                    </div>
                                </div>
                                <div class="mx-5">
                                    <div class="col-md-4">
                                        <img src="{{ asset('public/image/abc2.jpg') }}" class="d-block" alt="..."
                                            style="height:300px;width:400px;">
                                    </div>
                                    <div class="card-body">
                                        <h5 class="card-title mt-3">Double Your Sales by Turning Skeptics Into Customers
                                        </h5>
                                        <p class="mt-2 text-primary">Thu, Jan 23, 14:00 EST</p>
                                        <p class="card-text">Discover how to identify real objections versus smokescreens.
                                        </p>
                                        <a href="#" class="btn btn-warning">Reister Now</a>
                                    </div>
                                </div>
                                <div class="">
                                    <div class="col-md-4">
                                        <img src="{{ asset('public/image/abc5.webp') }}" class="d-block" alt="..."
                                            style="height:300px;width:400px;">
                                    </div>
                                    <div class="card-body">
                                        <h5 class="card-title mt-3">Maximize Your Earnings: Essential Tax Tips for
                                            Entrepreneurs in 2025</h5>
                                        <p class="mt-2 text-primary">Tue, Feb 11, 14:00 EST</p>
                                        <p class="card-text">Join our webinar on 2/11 with author, keynote speaker,
                                            Register now!</p>
                                        <a href="#" class="btn btn-warning">Reister Now</a>
                                    </div>
                                </div>
                            </div>
                            <div class="row mt-3">
                                <div class="col-md-12 center-position mar-top-20">
                                    <h2>Informational Services</h2>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <p>Despite advancements in technology and progressive policies, disparities in accessing
                                        social services persist, leaving many individuals and families struggling to
                                        overcome barriers imposed by poverty, discrimination, geographic isolation, and
                                        limited resources. Consequently, these communities face complex intergenerational
                                        challenges that hinder their development and perpetuate cycles of poverty.

                                        Recognizing the urgency of this issue, governments, non-profit organizations, and
                                        communities are coming together to identify effective strategies and collaborative
                                        approaches to bolster social services in underserved areas. By addressing the root
                                        causes of inequality and empowering local stakeholders, we can create sustainable
                                        solutions that build stronger, self-sufficient communities.

                                        This pursuit is not without its challenges, as it requires a multi-faceted approach
                                        that goes beyond simply allocating resources. Comprehensive solutions must take into
                                        account the unique cultural, historical, and socio-economic contexts of each
                                        community, respecting their inherent strengths and promoting community-led
                                        initiatives.</p>
                                </div>
                            </div>
                        </div>
                        <div class="text-center mb-5">
                            <p class="h1 text-center">Was this article is helpful?</p>
                            <button type="submit" class="true btn-lg btn h4 mx-3 mb-4"><i
                                    class="bi mx-2 bi-check2"></i>Yes</button>
                            <button type="submit" class="true btn-lg btn h4 mx-3 mb-4"><i class="bi mx-2 bi-x-lg"></i>
                                No</button>
                        </div>
                    </section>
                </section>
            </div>
        </div>
    </section>
@endsection
@section('script')
@endsection
